# Empire — imperadores e escudeiros: pesquisa aplicada e revisão dos conceitos

**Henrique Passos · 18 de outubro de 2026 · Revisão 5**  
**Estado:** estrutura de resolução, iluminação e expressões estudada antes do acabamento dos conceitos. O ZIP com animações completas continua dependente da aprovação dos desenhos, conforme o pedido original.

Esta revisão conserva o contrato de animação e o histórico útil, e acrescenta uma etapa de construção nativa. A preferência mais recente pelo rei, escudeiro, imperador sombrio e dançarina orienta o refinamento; as expressões do arqueiro/intendente e a densidade de pixels das pranchas anteriores ainda exigem remodelação.

## Revisão 5 — estrutura antes do acabamento

O estudo completo está em [EMPIRE-ESTRUTURA-LUZ-SOMBRA-64x64-V5.md](EMPIRE-ESTRUTURA-LUZ-SOMBRA-64x64-V5.md). Ele analisa as sete referências vegetais, reúne 12 fontes de pixel art, define a luz e as rampas por material e especifica o trabalho de cada personagem.

A prova nativa usa corpos de 64×64, com exceções de 96×96 para rei e imperador de armadura. As cabeças ocupam entre 18×20 e 26×26, incluindo acessórios; não são retratos de 64×64. Flores ficam em camadas próprias de 192×32, com o mesmo pixel de autoria e a mesma linha de chão dos personagens.

O pacote [EMPIRE-ESTUDOS-NATIVOS-V5.zip](EMPIRE-ESTUDOS-NATIVOS-V5.zip) inclui quatro painéis, PNGs estáticos, paleta, coordenadas editáveis e verificações de dimensões, continuidade facial e permanência do bigode. São **estudos de construção**, não personagens acabados. Não substituem a direção artística apreciada nem contêm ciclos completos.

A composição adicional de Sombra e floração explora um campo mais cheio, com famílias de plantas e alturas distintas. Ela ainda excede o detalhe da grelha nativa e não deve ser apresentada como sprite 64/96 validado. Os estudos de campo nativos comparam três paletas; continuam a precisar de acabamento artístico.

As seções seguintes registram a revisão 4. Nas decisões de escala, acabamento e estado de produção, esta seção e o estudo V5 prevalecem. Os testes técnicos não significam aprovação artística.

## 1. Direção que passa a orientar a produção

As instruções mais recentes de Henrique prevalecem sobre as propostas anteriores:

- Preservar o **nível de detalhe da primeira revisão do rei**. O ensaio posterior, excessivamente simplificado, não será a referência de acabamento.
- O nariz pertence à mesma rampa de pele do rosto. A sua cor base é a da testa e da bochecha; forma, perfil e sombra definem o volume. Retirar a mancha rosa ou vermelha usada nos ensaios.
- Cada personagem precisa de anatomia facial e atuação próprias. Um mesmo estado de jogo não exige a mesma expressão em todo o elenco.
- O rei usa a proposta de sobrevestimenta vinho, mangas marfim e capa curta azul-escura. A barriga permanece inteiramente coberta e as pernas distinguem-se sob a barra.
- O imperador de armadura fica **mais sombrio e assustador** e senta-se diretamente no chão. A recuperação faz nascer um campo de flores coloridas, criando contraste com a sua presença ameaçadora.
- O conceito da dançarina foi apreciado por Henrique e deve ser preservado.
- Todos os outros desenhos recebem revisão de gesto e peso para reduzir a rigidez. Bigodes, barbas e costeletas permanecem presentes em todas as expressões, incluindo golpe e ferido.
- Os acompanhantes e imperadores pequenos terão frames de 64×64. Os maiores podem ter frames superiores, conservando o mesmo pixel de autoria.

A preferência pelo detalhe da primeira versão não constitui aprovação automática dos quatro desenhos. A etapa atual apresenta as correções para essa avaliação.

### 1.1 O que foi apresentado nesta revisão

| Prancha | Conteúdo revisto |
| --- | --- |
| Rei e escudeiro | Roupa preservada; peso e poses revistos; quatro momentos de ação; seis expressões por rosto |
| Nia e bardo | Prontidão e movimentos de Nia; gesto musical do bardo; quatro estudos de ação e seis estados por rosto |
| Arqueiro e intendente | Poses com apoio e contrapeso; preparação e saída da flecha; fornecedor com bigode preservado na careta corrigida |
| Imperador de armadura e dançarina | Imperador escuro em pé e sentado no campo florido; quatro momentos da habilidade; conceito da dançarina preservado |

São **42 estudos faciais**, distribuídos pelos sete rostos visíveis, e quatro momentos de atuação corporal/floração para o imperador de elmo fechado. As pranchas são conceitos ampliados. A sua resolução total não certifica o tamanho nem a paleta de um futuro sprite de produção.

Foi acrescentada uma prova técnica independente com 18 amostras faciais em células nativas de 64×64, incluindo uma verificação de permanência do bigode. Ela demonstra o controlo da grelha e das alterações de expressão; não substitui o acabamento preferido nem aprova um desenho final.

## 2. Pesquisa: o que muda concretamente no trabalho

A pesquisa usa artigos dos próprios artistas, materiais de professores de animação e documentação oficial das ferramentas. As dimensões, cores e personalidades propostas para Empire são decisões de projeto, não regras universais extraídas dessas fontes.

### 2.1 Pixel art: detalhe útil dentro de uma resolução definida

Derek Yu trabalha o desenho, a limpeza das linhas e o volume em resoluções concretas. O seu segundo tutorial mostra como tons semelhantes, sombreado que acompanha o contorno e formas rígidas prejudicam a leitura. A aplicação a Empire é conservar o detalhe apreciado, mas concentrá-lo em volumes, dobras essenciais e materiais reconhecíveis [S01–S02].

Saint11 define a construção por grupos de pixels da mesma cor. O detalhe pode existir, mas deve apoiar massas legíveis. A discussão de antialias e banding também impede uma conclusão simplista: suavização manual não é universalmente proibida em pixel art. Neste projeto, a borda do sprite deve funcionar sobre cenários diferentes, sem halo pintado para um fundo específico [S03–S04].

O estudo de SLYNYRD sobre cavaleiros começa pela anatomia sob a armadura e organiza luz e sombra em grupos. Ele distingue explicitamente o detalhe de uma peça estática das exigências da animação. Para Empire, os elementos com maior custo de continuidade — correias pequenas, rebites, dedos, cabelo fragmentado — só entram quando contribuem para o desenho [S10].

**Consequência prática:** manter a riqueza das roupas e da armadura preferidas por Henrique; reduzir ruído e resolver as articulações; não aumentar a resolução dos olhos, dentes ou nariz para esconder problemas de desenho.

### 2.2 Expressão: intenção antes de trocar a boca

Dana Boadway-Masson trata a expressão como resposta do personagem ao que percebe. Isso orienta a pergunta anterior ao desenho: o que este indivíduo está a tentar mostrar ou esconder? O rei pode disfarçar o medo; o escudeiro pode expô-lo imediatamente. São leituras do mesmo acontecimento, com atuação diferente [S13].

Shawn Kelly sublinha que o rosto deve agir como uma unidade. A aplicação em baixa resolução é coordenar o ângulo das sobrancelhas, a abertura das pálpebras e a boca. Uma boca triste colada a olhos de vitória deixa de comunicar a intenção, mesmo que cada elemento isolado esteja bem desenhado [S14].

Os estudos de faces de SLYNYRD reforçam a necessidade de simplificar e posicionar os traços na grelha. São estudos de retratos e estética anime; servem aqui para estudar organização e perfil. Não autorizam importar olhos grandes ou a resolução desses retratos para os sprites pequenos do Empire [S12].

**Consequência prática:** fixar a identidade do rosto e, em seguida, desenhar estados específicos dessa identidade. A boca do bardo é mais vertical e expansiva; a do arqueiro é estreita e contida; o bigode limita a boca visível do intendente.

### 2.3 Consistência: comparar em sequência, não apenas lado a lado

No estudo de personagem em várias direções, SLYNYRD identifica erros de proporção que aparecem quando as vistas são sequenciadas. Também explica como um detalhe atraente numa pose pode criar ruído em movimento. Para Empire, a validação inclui reproduzir a troca de expressões e as poses extremas antes de multiplicar ciclos [S09].

Saint11 discute consistência de resolução, posição e rotação. Aqui, a regra é manter uma grelha de autoria, deslocamentos inteiros nos detalhes do rosto e uma escala comum no mundo do jogo. A ampliação de apresentação não pode criar uma segunda resolução dentro do mesmo sprite [S05].

A documentação de Aseprite fornece ferramentas concretas para a revisão: camadas, quadros, tags, onion skin e cels vinculadas. Estas últimas partilham imagem e posição; exigem atenção para não propagar uma alteração de expressão a quadros que deveriam continuar diferentes [S15–S17].

**Consequência prática:** comparar a silhueta e os pixels de identidade com uma referência fixa, limitar as mudanças à região facial apropriada e rever a expressão no contexto da cabeça e do corpo em movimento.

### 2.4 Animação: poses fortes e ações que respeitam o jogo

SLYNYRD mostra que quantidade de quadros não equivale automaticamente a energia ou boa leitura. As poses principais e o tempo de exposição continuam decisivos. O estudo lateral de ataques também relaciona arma, postura e resposta ao comando [S06–S07].

O estudo lateral de 2026 parte de um corpo simples e acrescenta equipamento e movimento secundário depois. Essa separação orienta o trabalho de capas, bandeira, aljava e armadura. Não implica acrescentar ao Empire as mecânicas de tiro daquele exemplo [S11].

**Consequência prática:** aprovar corpo, rosto e poses extremas; produzir as ações com os tempos do projeto; ligar o evento de flecha, bloqueio ou recuperação ao momento visual correto.

### 2.5 Rigidez: trabalhar a força da pose

Anthony Wong propõe avaliar significado, silhueta, linha de ação e oposição entre quadril e ombros. Os exemplos mostram que a simetria e o alinhamento do corpo com as bordas do enquadramento podem enfraquecer uma pose. A aplicação aqui é redesenhar o apoio e o gesto, envolvendo tronco, braços e pernas na mesma intenção [S19].

Jay Jackson relaciona a linha de ação com peso, equilíbrio e oposição das curvas. Para Empire, isso não significa deformar o crânio nem tornar a armadura flexível: a curva principal atravessa as articulações; as placas continuam a encaixar sobre elas [S20].

O estudo de postura de combate de SLYNYRD ajuda a decompor o repouso ativo em pequenos movimentos coordenados. A referência orienta a produção posterior; os novos estudos estáticos mostram as poses que o ciclo deverá ligar [S21].

| Personagem | Organização da pose a trabalhar |
| --- | --- |
| Rei | Barriga à frente, ombros recuados e quadril sobre a perna de apoio; passada curta e braços assimétricos |
| Escudeiro | Curva de esforço atrás do escudo, cotovelos fletidos e joelhos a receber a carga |
| Nia | Corpo compacto em prontidão, quadril e ombros em oposição, gesto que continua pela mão da arma |
| Bardo | Peito e cabeça acompanham o canto; alavanca do alaúde e apoio dos pés equilibram a pose |
| Arqueiro | Curva longa e contida, braço de mira estável e braço de puxada articulado |
| Intendente | Corpo compensa a aljava, joelho cede e a mão do pagamento permanece clara na silhueta |
| Imperador | Massa ameaçadora com ombros desiguais, cabeça afundada e articulações pesadas; descanso baixa o peso até ao solo |
| Dançarina | Preservar o conceito que Henrique apreciou, incluindo os apoios, os gestos e a leveza |

### 2.6 Ameaça e campo florido: contraste de forma e valor

Na entrevista com Chris Bourassa, a direção de Darkest Dungeon relaciona massas escuras e acabamento envelhecido ao tom do jogo. A referência é de intenção tonal, não de técnica de pixel art nem de personagem para copiar [S22].

Para o imperador, a nova decisão combina elmo fechado e estreito, armadura de ferro escuro, ombreiras angulares desiguais e uma postura que avança sobre o espaço. A leitura das placas conserva alguns planos de luz; escurecer tudo até perder a anatomia não resolveria o desenho.

Ao sentar, o mesmo personagem conserva a aparência sombria. A mudança é o gesto e o aparecimento do campo florido. Pétalas pequenas e vivas, distribuídas horizontalmente, criam o contraste com a massa escura sem mudar a identidade da armadura.

## 3. Escala, paleta e prova de construção nativa

### 3.1 Frame, corpo e rosto são medidas diferentes

Uma célula de 64×64 pode conter um corpo de 44 px e margem para as machadinhas. O chapéu ou a bandeira não devem tornar o corpo do bardo artificialmente maior. A reserva de margem precisa de ser testada na extensão máxima da ação.

| Personagem | Frame proposto | Altura útil orientadora, em pé | Região orientadora da cabeça |
| --- | --- | --- | --- |
| Rei | 96×96 | 70–76 px | Aproximadamente 22–26 px |
| Escudeiro protetor | 64×64 | 36–44 px | Aproximadamente 14–18 px com elmo |
| Nia | 64×64 | 42–46 px | Aproximadamente 16–20 px com cabelo |
| Bardo | 64×64 | 40–44 px de corpo; conjunto até 56 px | Aproximadamente 18–22 px com chapéu |
| Arqueiro | 96×96 | 64–70 px | Aproximadamente 18–22 px com capuz/coroa |
| Intendente | 64×64 | 35–40 px; conjunto até 54 px | Aproximadamente 16–18 px com gorro |
| Imperador de armadura | 128×128 | 90–98 px | Volume do elmo e encaixe entre ombreiras |
| Dançarina | 64×64 | 40–45 px | Aproximadamente 14–18 px, além do coque |

São metas para a autoria final. A validação compara o elenco na mesma linha de chão e sobre os cenários do jogo. O imperador sentado fica naturalmente mais baixo sem que o seu corpo seja reduzido por escala.

### 3.2 Detalhe moderado e cor do nariz

- Dois tons por tecido como ponto de partida; um terceiro só quando tiver função clara.
- Materiais distinguem-se pela organização das massas: metal com acentos concentrados; linho com dobras amplas; couro com blocos pequenos bem colocados.
- Testa, bochecha e parte iluminada do nariz partilham a cor base de pele do personagem.
- A sombra sob o nariz usa a rampa de pele já existente, sem uma mancha cromática independente.
- Olhos, dentes e fivelas não recebem detalhe abaixo da grelha usada pelo resto do personagem.
- Um ou dois grupos de dentes comunicam melhor a expressão pequena do que uma dentição desenhada individualmente.
- A identidade deve sobreviver em fundo claro e escuro. Contorno e contraste interior são avaliados separadamente.

O detalhe não é medido por uma proibição absoluta de pixels isolados. Um olho ou um acento pode justificar um deles; dezenas de pontos sem função enfraquecem a leitura.

### 3.3 Prova técnica produzida e verificada

A folha EMPIRE-ROSTOS-PROVA-NATIVA-64x64.png contém **18 células de 64×64**, organizadas em seis colunas e três linhas; o arquivo completo mede **384×192**.

O rei foi construído numa grelha de 24×24, o escudeiro numa de 16×16 e o intendente numa de 20×20, com coordenadas inteiras e paleta explícita. São amostras didáticas independentes, não redução automática das pranchas e não sprites corporais finais.

A conferência dos PNGs exportados verificou:

| Verificação realizada | Resultado |
| --- | --- |
| Quantidade e tamanho das células | 18 células; todas 64×64 |
| Canal alpha | Apenas 0 e 255 |
| Cores opacas por cabeça | 7–8 nesta demonstração |
| Silhueta externa durante a troca de expressão | Idêntica nas seis variantes de cada cabeça |
| Pixels fora das regiões faciais autorizadas | Sem alterações entre estados |
| Nariz na cor base da pele | Verificado nas três séries |
| Bigode do intendente | Todos os pixels da camada preservados nos seis estados |
| Estados distintos | Seis imagens diferentes por cabeça |
| Ampliação de inspeção | 6× por nearest neighbor, com exemplo a 1× |

A prova verifica integridade da construção. A avaliação da beleza, da personalidade e do nível de detalhe continua a depender da revisão artística e das pranchas preferidas.

Arquivos complementares: [folha nativa](EMPIRE-ROSTOS-PROVA-NATIVA-64x64.png) e [painel de inspeção](EMPIRE-PROVA-EXPRESSOES-GRELHA.png).

## 4. Identidade e atuação de cada personagem

Uma expressão original depende da combinação de anatomia, comportamento e situação. A diferenciação não será sustentada apenas pela cor da roupa ou pelo chapéu.

| Personagem | Traços de identidade | Comportamento que orienta o rosto |
| --- | --- | --- |
| Rei | Rosto largo, queixo duplo, pálpebras pesadas, nariz arredondado na rampa da pele | Quer parecer no controlo; exagera a satisfação e tenta esconder o receio |
| Escudeiro | Cabeça mais estreita, nariz curto, olhos sob o elmo, boca pequena e um dente frontal | Antecipa os perigos e esforça-se por cumprir o dever apesar do medo |
| Nia | Mandíbula compacta, maçãs do rosto marcadas, nariz curto, sobrancelhas ativas e olhar estreito | Confiança inquieta e prontidão; desafia antes de hesitar |
| Bardo | Nariz mais longo e curvo, bochechas redondas, queixo menor, boca vertical expansiva | Vive a situação como atuação; ouvir, cantar e perder a voz são estados diferentes |
| Arqueiro | Rosto comprido, queixo fino, nariz longo, pálpebra horizontal e sorriso de canto | Mantém distância e confiança; mira com contenção e procura parecer infalível |
| Intendente | Rosto quadrado, nariz baixo e largo, bigode dominante, sobrancelhas pesadas | Observa o pagamento e mostra impaciência; a satisfação aparece discretamente |
| Imperador de armadura | Elmo fechado estreito, ferro escuro e ombreiras angulares desiguais | Ameaça e peso em pé; cansaço e repouso no chão, conservando a identidade sombria durante a floração |
| Dançarina | Rosto afunilado, queixo pequeno, nariz curto, coque e sobrancelhas arqueadas | Atenção leve e curiosidade; energia nos gestos, alegria de alívio e vulnerabilidade contida |

Estas escolhas mantêm o mesmo tratamento de caricatura em todo o elenco. A personalidade de Nia vem da atuação, postura e desenho próprio, preservando a sua identidade de mulher negra adulta.

### 4.1 O mesmo estado não produz a mesma cara

| Estado | Rei | Escudeiro | Bardo | Arqueiro | Intendente |
| --- | --- | --- | --- | --- | --- |
| Calma | Satisfação convencida | Atenção nervosa | Escuta e pequeno murmúrio | Segurança distante | Espera pelo pagamento |
| Foco | Ordem contrariada | Determinação tensa | Concentração musical | Olho de mira estreito | Conta e desconfia |
| Medo | Tenta sustentar uma falsa segurança | Alarme evidente e queixo recolhido | Perde o fio da canção | A confiança vacila | Indignação alarmada |
| Golpe | Dor ofendida | Encolhe-se para suportar | Careta curta e boca contraída | Reação oblíqua contida | Resmungo sob o bigode |
| Ferido | Cansaço que procura esconder | Desânimo fatigado | Perde a voz e a energia | Frustração exausta | Resignação |
| Vitória | Grande sorriso público | Alívio surpreso | Canto teatral | Satisfação de canto | Pequeno sorriso lateral |

Nia usa tensão curta e precisa no foco, vigilância no medo, irritação cansada ao ficar ferida e um sorriso provocador na vitória. A dançarina mantém alarmes menores, olhos e lábios mais suaves e uma alegria de alívio.

O estado ferido não será comunicado por pintar o nariz de outra cor. As pálpebras, a boca, o apoio do corpo e os estados já definidos pelo jogo cumprem essa função.

## 5. Método para prevenir e encontrar falhas

### 5.1 Modelo de identidade por personagem

Antes de animar, fixar uma cabeça neutra por vista e registar o seu tamanho, linha dos olhos, perfil do nariz, queixo e ligação ao pescoço. Coroa, elmo e cabelo acompanham essa cabeça. O modelo é confrontado com o corpo e com os companheiros do elenco.

A expressão altera os grupos destinados a sobrancelhas, pálpebras e boca, com eventual acento de bochecha. Não altera involuntariamente a largura do crânio, o número de dentes visíveis, o comprimento do nariz ou o tamanho da coroa. O projeto proíbe squash and stretch da cabeça; a atuação respeita essa regra.

### 5.2 Conferência facial

1. Rever a cabeça neutra sem equipamento a ocultar os seus pontos de referência.
2. Ler cada estado a 1× antes de ampliar.
3. Comparar normal/foco, medo/golpe e ferido/vitória. Cada par precisa de sinais diferentes em mais de uma região facial.
4. Alternar os estados na mesma posição para identificar deriva de volume.
5. Cobrir temporariamente a boca e avaliar olhos/sobrancelhas; depois fazer o inverso. O teste ajuda a localizar dependência excessiva de um único sinal, sem exigir leitura completa de toda a emoção por cada região isolada.
6. Conferir direção das pupilas e intenção do olhar na vista de jogo.
7. Conferir que a sombra do nariz não se transformou numa cor independente.
8. Rever a expressão no corpo inclinado, a andar, a atacar e a receber impacto.

### 5.3 Conferência de movimento e equipamento

| Falha a procurar | Como verificar/corrigir |
| --- | --- |
| Rosto a deslizar sobre a cabeça | Conferir o ponto da cabeça em cada quadro; mover a expressão com esse ponto |
| Cabeça a aumentar numa careta | Comparar máscara externa e medidas com a pose correspondente |
| Cabelo, elmo ou coroa a saltar | Rever sobreposição entre quadros e posições de encaixe |
| Dentes que mudam aleatoriamente | Conservar grupos e espaços de identidade nas aberturas relevantes |
| Olho fora do rosto ou olhar incoerente | Conferir vista de jogo e região disponível sob a pálpebra/elmo |
| Arma a atravessar o rosto | Rever a pose extrema e o espaço entre cabeça, mão e equipamento |
| Troca de mão por espelhamento | Conferir os dois sentidos e documentar a assimetria escolhida |
| Um ajuste a propagar-se a todos os estados | Conferir cels vinculadas antes de editar expressões independentes |
| Tremulação de detalhe | Reproduzir o ciclo na velocidade de jogo, além de percorrer os quadros |
| Cura, dano ou flechas acionados pelo desenho | Conferir a ligação ao evento da simulação; o efeito só apresenta o resultado |

A expressão de impacto é transitória. Ao terminar, o rosto volta ao estado que a personagem realmente tem, incluindo ferido quando aplicável. A produção não deve assumir que qualquer reação regressa sempre ao sorriso neutro.

### 5.4 Continuidade de bigodes, barbas e costeletas

O desaparecimento do bigode na careta do intendente foi um erro de continuidade da prancha. A versão revista corrige esse estado: o bigode conserva os dois lados e a boca de impacto fica fechada por baixo, enquanto olhos e sobrancelhas comunicam a dor.

Na autoria de produção, bigode, barba e costeletas são partes persistentes da identidade:

- O bigode liga-se à região do lábio superior; os seus dois lados e pontos de implantação continuam presentes.
- A barba acompanha a mandíbula e a inclinação da cabeça. Abrir a boca pode alterar a sua projeção, mas não a elimina.
- A boca tem uma região própria e uma ordem de sobreposição definida com o pelo facial.
- Uma careta com dentes não pode pintar por cima do bigode e substituí-lo por uma faixa branca.
- Há variantes desenhadas quando a abertura da boca ou a vista exige outra projeção do pelo. A variante conserva volume, implantação e identidade.
- Costeletas e cabelo sob o elmo também são conferidos em impacto, ferido, queda e mudança de direção.

A prova nativa inclui agora o intendente com uma camada de bigode aplicada depois da boca. A conferência verifica todos os pixels dessa camada nas seis expressões. É uma demonstração estrutural de prevenção do erro, além da correção visual da prancha.

Fixar esta continuidade não exige colar a mesma imagem rígida de cabelo sobre qualquer pose. Uma vista diferente ou movimento da mandíbula pode exigir redesenho; a presença e a estrutura do traço permanecem coerentes.

### 5.5 Conferência da rigidez

Antes de acrescentar acabamento, ler as poses principais como massas. Confirmar qual pé sustenta o corpo, para onde vai a força, como os ombros se opõem ao quadril e se o gesto atravessa as articulações. Comparar antecipação e ação: a segunda deve desenvolver a força preparada pela primeira.

A pose não fica viva apenas por desenhar uma capa ondulada. O corpo precisa de participar. Também não é necessário exagerar todo o movimento: o imperador transmite massa e o arqueiro precisão; o bardo pode ter um gesto muito mais expansivo.

### 5.6 Critério de conclusão

Um PNG com dimensões certas pode ter desenho ou atuação fracos. Uma prancha bonita pode não conter frames utilizáveis. A entrega de animações precisará passar por integridade dos arquivos, revisão artística e reprodução no jogo. Nenhuma destas camadas substitui as outras.

## 6. Imperador: sentar no chão e fazer nascer flores

Esta revisão torna a presença do imperador mais ameaçadora e elimina o suporte sob ele. A capa pode tocar o terreno; não funciona como assento elevado. O corpo mantém o seu volume ao baixar. A armadura e o elmo escuros mantêm o mesmo desenho ao surgir o campo florido, sem ganhar uma cara sorridente ou cores brilhantes.

### 6.1 Anatomia e peso da ação

- A descida envolve quadril e joelhos; o tronco compensa o peso antes do contacto.
- O apoio termina diretamente no solo, com as pernas à frente e as botas separadas o suficiente para ler a pose.
- As mãos repousam sobre os joelhos e os ombros descem.
- Ombreiras, cotovelos e joelheiras conservam a articulação. Não se comprime toda a armadura como uma peça de borracha.
- O elmo inclina-se com cansaço. Ao recuperar, o alívio é pequeno e corporal.
- Ao levantar, o peso precisa voltar aos pés antes de o corpo completar a subida.

### 6.2 Sequência visual proposta

| Momento | Corpo | Plantas |
| --- | --- | --- |
| Descer | Quadril baixa; joelhos dobram; massa ainda sustentada | Chão livre |
| Sentar | Nádegas assentes; pernas à frente; mãos nos joelhos | Chão livre |
| Brotar | Corpo já estabilizado na pose de repouso | Folhas pequenas e botões em pontos definidos |
| Florir | Mesmo corpo sentado | Flores rosa/magenta, amarelas e azuis com centros claros |
| Recuperar | Respiração e pequeno movimento de repouso | Crescimento concluído; movimento discreto quando necessário |
| Levantar | Transferência de peso e regresso ao apoio | Continuidade visual definida pela duração do efeito |

Os quatro estudos da faixa de sequência apresentada mostram os primeiros quatro momentos. Eles não são uma folha final com o ciclo completo de levantar.

Como proposta de autoria, a descida pode partir de seis quadros a 10 fps e o repouso usa os oito quadros previstos para heal. O crescimento recebe uma linha de tempo própria. Estes números não alteram a cura ou o tempo da habilidade na simulação.

### 6.3 Construção das flores

- Flores pequenas mas cromaticamente claras: três famílias principais de pétalas, com folhas e caules a sustentá-las.
- Controlo de grupos em vez de pontos coloridos dispersos.
- Botões surgem nos mesmos pontos em que as flores abrem.
- A flor cresce a partir do solo. Não nasce do elmo, de uma luva ou de dentro da armadura.
- A vegetação conserva intervalos em torno de botas e mãos, para não esconder o contacto com o chão.
- As flores pertencem ao efeito do imperador. A pose da dançarina não a transforma na fonte da floração.

### 6.4 Regras para a futura integração

O corpo e a flora são camadas independentes. A referência do efeito é um ponto de chão coerente com a posição do personagem. A origem de apresentação mantém-se estável ao sentar; não é recalculada pelo retângulo aparente do corpo.

O evento de entrada no estado de repouso inicia o efeito uma vez. O loop corporal não deve gerar uma nova camada de flores em cada repetição. O número de elementos e a ordem de crescimento precisam ser estáveis para a mesma execução visual.

Interrupção, saída e nova entrada na habilidade precisam de ser revistas: sem flores duplicadas, corpo a saltar para outra posição, plantas suspensas ou desaparecimento abrupto no meio de um quadro. A persistência das flores e a sua eventual função no mundo continuam decisões de gameplay; o conceito não lhes atribui colisão, recursos, dano ou bónus adicionais.


## 7. O que “animações completas” deverá incluir

A entrega só deve usar essa expressão quando cobrir os estados da personagem, os dois sentidos de leitura necessários e as ações do seu papel. Uma folha de caminhada isolada não cobre o pedido.

### Base comum proposta

Os quatro ciclos centrais vêm da Animation Bible. Os demais são propostas de produção e precisam acompanhar as ações existentes no jogo.

| Tag de autoria | Quadros orientadores | Comportamento |
| --- | --- | --- |
| idle | 6 | Respiração e atuação própria, com pés estáveis |
| walk | 8 | Contatos opostos e passagem; deslocamento no mundo vem da simulação |
| attack | 5 | Antecipação, ação e recuperação; corpo ofensivo conforme o papel |
| die | 7 | Queda e pose final legível; não significa morte definitiva automática |
| run | 6 | Corrida com apoios e fôlego visível |
| hit | 2 | Reação curta, mantendo ancoragem |
| turn | 2–3 | Mudança de direção sem salto involuntário do pivot |
| interact | 4 | Gesto de interação |
| celebrate | 6 | Vitória coerente com personalidade |
| rise | 6, proposta | Voltar ao apoio depois de recuperação válida |
| flee | 6 | Acompanhantes nos estados de recuo/fuga aplicáveis |

A regra central documentada é 10 fps para idle/walk/attack/die. A própria Bible apresenta cadências distintas para alguns extras. As durações serão registradas por quadro, sem transformar essa tabela numa alteração dos tempos de combate.

A queda do rei e a coroa precisam respeitar as regras da simulação. A coroa deve poder sair do corpo, permanecer no chão e seguir o evento correto; pintar uma coroa presa em todos os quadros de queda causaria contradição visual.

### Ações específicas por dupla

| Personagem | Conjuntos específicos a produzir após aprovação |
| --- | --- |
| Rei | Ataque de espada, ordem/Vigília, pagar, recolher moeda e reação à perda da coroa |
| Escudeiro | Preparar bloqueio, sustentar, receber impacto, perder proteção, equipar; espada e ataque na evolução |
| Nia | Ataque curto com as duas machadinhas e ordem à companhia; variação de pose não cria uma habilidade nova |
| Bardo | Tocar, encantar, incentivar, sinalizar serviço indisponível e promover na evolução de Maestro |
| Arqueiro | Preparar, puxar, soltar, recuperar/recarregar, marcar, pagar e sinalizar aljava vazia |
| Intendente | Receber pagamento, buscar e entregar flechas, sinalizar falta de pagamento; preparar e disparar na evolução |
| Imperador de armadura | Passo pesado, sentar, recuperar e levantar; combate conforme armamento posteriormente fechado |
| Dançarina | Início da dança, ciclo de apoio, transição e fim; diferenciação da dança evoluída e seu efeito |

Ataques, pagamento e conversão precisam de um momento de ação identificável. Um efeito visual não concede dano, flechas, cura ou conversão por conta própria.

### Movimento secundário

- Rei: capa e massa abdominal acompanham o corpo com atraso pequeno.
- Escudeiro: escudo responde à força, não balança sem peso.
- Nia: capa curta e arma livre seguem trajetórias independentes.
- Bardo: tecido da bandeira e pena acompanham a atuação sem cobrir o rosto.
- Arqueiro: corda, membros do arco e braço de puxada distinguem preparação e disparo.
- Intendente: a carga de flechas acompanha o tronco sem se desmontar em pixels soltos.
- Imperador: ombreiras e placas conservam volume, com os apoios transmitindo peso.
- Dançarina: tecido segue a viragem; pés continuam mostrando qual lado sustenta o corpo.

## 8. Direções, pivots e camadas

A apresentação principal deve funcionar virada à direita e à esquerda. A comparação incluirá mão da arma, perfil do rosto, aljava, escudo e bandeira.

O runtime atual usa espelhamento. Se uma assimetria exigir arte própria para cada lado, exportar duas direções só resolverá a autoria: a seleção da direção também precisará de ligação na apresentação do jogo. Essa diferença deve ficar documentada.

O pivot é o contato central dos pés no frame de referência. Ele permanece fixo nas tags. Na queda, a extensão visual muda; a origem do personagem não deve saltar.

Camadas de autoria propostas:

- body: torso e membros.
- head/face: identidade e expressão.
- weapon/shield: equipamento móvel.
- cloth: capa, bandeira e tecido relevante.
- crown: destacável quando a regra pedir.
- fx: arcos de ataque, notas, sinais e vegetação, exportados separadamente quando apropriado.

Pontos de referência por quadro: mão da arma, origem de projétil, cabeça, mão de transporte e origem de efeito. Os dados precisam dizer se são coordenadas locais do frame ou offsets em relação ao pivot.

## 9. Compatibilidade concreta com o código atual

O estudo anterior consultou o manifesto de renewal e a leitura de arte em OriginalArt/ActorAction no commit indicado na secção 12. As observações seguintes referem-se a esse retrato documental.

### Estado observado no estudo anterior

Nos seis perfis iniciais das duplas, o manifesto atual usa células de **192×192**, com quatro quadros por personagem. As tags são idle 0–0, walk 0–3 e flee 0–3; as durações registradas são 160 ms. A tela de 192×192 inclui transparência: esse número não equivale à altura do corpo visível.

OriginalArt já lê tamanho de frame, foot, regiões, duração e tags. Isso dá uma base para células de dimensões diferentes. Porém, a entrada de renewal tem prioridade: os novos perfis precisam ser ligados ao lugar efetivamente lido pelo runtime.

ActorAction conhece idle, walk, work, attack, hit, flee e die. As ações específicas como tocar, entregar flechas ou marcar não estão todas mapeadas nessa seleção genérica.

### Consequência para o futuro ZIP

O pacote deve trazer arte e metadados compatíveis, com indicação clara do que está pronto para importação e do que requer ligação de evento. A presença de uma tag nova num JSON não comprova que a simulação já a dispara.

O trabalho de integração posterior precisará:

1. Ligar os novos tamanhos e pivots ao manifesto realmente selecionado.
2. Confirmar que cada ação visual corresponde ao estado/evento certo.
3. Sincronizar a saída da flecha e o impacto ao evento de combate, preservando a autoridade da simulação.
4. Tratar ações únicas e loops corretamente.
5. Verificar inversão lateral e camadas de equipamento.
6. Comparar os personagens sobre cenários claros e escuros do jogo.
7. Conferir a visualização no enquadramento normal e em dispositivo pequeno.

Os conceitos não alteram essas ligações e não foram apresentados como arte já integrada.

## 10. Organização prevista do ZIP

| Pasta | Conteúdo |
| --- | --- |
| 01-frames | PNGs transparentes individuais, agrupados por personagem, forma, direção e ação |
| 02-spritesheets | Folhas por personagem e ação, sem texto dentro das células |
| 03-metadata | Tamanho, pivot, regiões, tags, durações, loops, pontos e eventos visuais |
| 04-previews | GIFs de cada ação e reprodução conjunta para revisão |
| 05-godot | Manifesto e instruções de importação para o caminho real do projeto; prévia quando aplicável |
| 06-fontes | Fontes de autoria e camadas efetivamente produzidas, identificadas pelo formato real |
| LEIA-ME.md | Relação das ações entregues, dimensões, uso e pendências concretas |

Amostras de nome: nia_base_right_attack_003.png; squire_base_left_block_002.png; quiver_squire_evolved_right_shoot_003.png.

As formas evoluídas devem ser identificadas separadamente. A completude será conferida contra uma lista de ações por personagem, evitando uma contagem de arquivos que esconda estados ausentes.

## 11. Critérios para aceitar os sprites de produção

### Integridade

- As imagens pequenas medem efetivamente 64×64; grandes correspondem ao tamanho aprovado.
- Alpha fora do corpo e transparência correta nas folhas.
- Nenhuma arma, pena ou fita cortada na borda.
- Regiões válidas e nomes únicos.
- Durações positivas, tags válidas e ciclos com início/fim corretos.
- Arquivo-fonte abre no formato declarado.

### Desenho

- Cabeça e membros conservam massa de um quadro para outro.
- Rosto continua reconhecível nas poses extremas.
- Contorno, paleta e densidade pertencem à mesma família.
- Armas têm empunhadura, orientação e alcance visual compreensíveis.
- A leitura de silhueta distingue os oito personagens.
- Nenhum acompanhante foi aumentado por escala de renderização para compensar falta de desenho.
- O porte do personagem continua coerente com portas, tropas e cenário.

### Movimento e jogo

- Pés de apoio não flutuam ou deslizam involuntariamente.
- Caminhada e corrida têm poses de contato e passagem reais.
- Cada ataque possui antecipação e recuperação adequadas à arma.
- O projétil desaparece do arco ao ser lançado.
- Pagamento e entrega têm mãos e objeto em posições coerentes.
- O bardo executa a ação musical; Nia ordena.
- A dançarina mantém equilíbrio e continuidade do tecido.
- O último quadro da queda permanece legível no chão.
- Os ciclos repetem sem um salto visível entre último e primeiro quadro.
- A animação foi vista em loop e em transições, além da inspeção estática.

A validação artística é do autor. Medir arquivos e verificar tags é necessário, mas não substitui a aprovação de personalidade, rosto e movimento.

## 12. Fontes primárias consultadas

Acessadas em 18/10/2026. As sínteses foram aplicadas às decisões específicas do projeto; não se copiaram sprites de terceiros.

| ID | Fonte | Utilidade nesta revisão |
| --- | --- | --- |
| S01 | [Derek Yu — Pixel Art Tutorial: Basics](https://derekyu.com/makegames/pixelart.html) | Resolução, linhas, volume, paleta e limites do detalhe |
| S02 | [Derek Yu — Common Mistakes](https://derekyu.com/makegames/pixelart2.html) | Tons semelhantes, pillow shading e desenho rígido |
| S03 | [Saint11 — Cluster Sketching and Painting](https://saint11.art/pixel_art_articles/article2/) | Organização por grupos de pixels e uso intencional do detalhe |
| S04 | [Saint11 — Anti-Alias and Banding](https://saint11.art/pixel_art_articles/article5/) | Limpeza das transições e controlo das bordas |
| S05 | [Saint11 — Consistency](https://saint11.art/blog/consistency/) | Coerência de resolução, posição, escala e rotação |
| S06 | [SLYNYRD — Pixelblog 8: Intro to Animation](https://www.slynyrd.com/blog/2018/8/19/pixelblog-8-intro-to-animation) | Poses principais, energia e duração dos quadros |
| S07 | [SLYNYRD — Pixelblog 9: Melee Attacks](https://www.slynyrd.com/blog/2018/9/8/pixelblog-9-melee-attacks) | Peso da arma, antecipação e resposta ao comando |
| S08 | [SLYNYRD — Pixelblog 22: Top Down Character Sprites](https://www.slynyrd.com/blog/2019/10/21/pixelblog-22-top-down-character-sprites) | Relação de escala entre personagem, frame e ambiente |
| S09 | [SLYNYRD — Pixelblog 55: Top Down Character Animation](https://www.slynyrd.com/blog/2025/3/24/pixelblog-55-top-down-character-animation) | Consistência de anatomia e detalhes durante as poses |
| S10 | [SLYNYRD — Pixelblog 57: Knights, Monsters & Castles](https://www.slynyrd.com/blog/2025/7/28/pixelblog-57-knights-monsters-amp-castles) | Corpo sob armadura, materiais e massas de luz |
| S11 | [SLYNYRD — Pixelblog 60: Side View Run ’N Gun](https://www.slynyrd.com/blog/2026/1/26/side-view-run-n-gun) | Corpo lateral, equipamento, roupa e movimento secundário |
| S12 | [SLYNYRD — Pixelblog 29: Anime Faces and Hair](https://www.slynyrd.com/blog/2020/7/28/pixelblog-29-anime-faces-and-hair) | Organização dos traços e do perfil; limites da aplicação de retratos aos sprites |
| S13 | [Dana Boadway-Masson — Facial Animation 101](https://www.animationmentor.com/blog/facial-animation-101/) | Intenção, reação e construção da atuação facial |
| S14 | [Shawn Kelly — Learn How to Animate Your Character’s Face](https://www.animationmentor.com/blog/how-to-get-great-expressions-and-animate-faces/) | Coerência do rosto como unidade expressiva |
| S15 | [Aseprite — Animation](https://www.aseprite.org/docs/animation/) | Quadros, camadas, tags e organização |
| S16 | [Aseprite — Onion Skinning](https://www.aseprite.org/docs/onion-skinning/) | Comparação de quadros e pontos de referência |
| S17 | [Aseprite — Linked Cels](https://www.aseprite.org/docs/linked-cels/) | Partilha de imagem/posição e prevenção de alterações propagadas |
| S18 | [Godot — Multiple Resolutions](https://docs.godotengine.org/en/stable/tutorials/rendering/multiple_resolutions.html) | Escala inteira e apresentação sem deformar os pixels |
| S19 | [Anthony Wong — Building Appealing Character Poses](https://www.animationmentor.com/blog/tutorial-building-appealing-character-poses-for-animation/) | Gesto, peso, silhueta, espaços entre membros e oposição entre quadril e ombros |
| S20 | [Jay Jackson — Solid Drawing](https://www.animationmentor.com/blog/solid-drawing-the-12-basic-principles-of-animation/) | Linha de ação, equilíbrio e assimetria |
| S21 | [SLYNYRD — Pixelblog 52: Idle Fighting Stance](https://www.slynyrd.com/blog/2024/9/26/pixelblog-52-idle-fighting-stance) | Decomposição da postura ativa e relação entre os movimentos |
| S22 | [Chris Bourassa — entrevista sobre Darkest Dungeon](https://www.gamedeveloper.com/audio/road-to-the-igf-red-hook-studios-i-darkest-dungeon-i-) | Massas escuras e intenção tonal; não é referência de resolução ou sprite |

Na documentação Godot, a escala inteira evita que pixels sejam apresentados com larguras diferentes durante o redimensionamento. Esse controlo será conferido na integração; não foi alterado nesta etapa [S18].

### Base documental do Empire

O estudo anterior consultou a main no commit [0c351775e2c569e83fc746ca339202753cd203ae](https://github.com/henriquecoding/empire/commit/0c351775e2c569e83fc746ca339202753cd203ae). Esta revisão reutiliza as cópias desse estudo, em particular:

- docs/design/08-imperadores-companhias-e-desbloqueios.md
- docs/art/EXPRESSION_GUIDE.md
- docs/art/REFERENCE_AUTHORITY.md
- docs/art/ANIMATION_BIBLE.md
- docs/art/ASSET_BIBLE.md
- data/source/monarchs.csv
- src/actors/original_art.gd e src/actors/actor_action.gd

A secção de compatibilidade descreve esse retrato documental, não uma nova auditoria da main ou um playtest do deployment. Nenhum desenho foi integrado no jogo nesta etapa.

## 13. Estado da entrega e próxima etapa autorizada

A pesquisa e os conceitos revistos estão entregues para avaliação. O detalhe preferido, os narizes no tom da pele, a continuidade de bigodes/barbas, as poses menos rígidas e o imperador sombrio no campo florido orientam a produção seguinte. O conceito da dançarina permanece como referência apreciada por Henrique.

As pranchas foram criadas pela ferramenta integrada de geração/edição de imagens, com as referências do Empire. A prova de grelha foi construída separadamente por coordenadas inteiras para permitir verificação objetiva.

A produção de animações completas começará após a aprovação dos conceitos, como Henrique pediu originalmente. Deve incluir as ações, metadados, transparência, fontes e prévias definidos neste contrato. O combate do quarto imperador continua a exigir definição do seu armamento; a recuperação no chão e a floração já têm orientação visual nesta revisão.

## Anexo — especificações das pranchas revistas

Os prompts registam as instruções da revisão. O resultado exige inspeção visual e, na produção nativa, validação dos arquivos.

### Rei e escudeiro

```text
Use case: stylized-concept. Deep refinement of EMPIRE's king and protective squire, preserving the approved direction of DETAIL and CLOTHES while giving the designs convincing fluidity and personality.
Reference supplies the king's burgundy sleeveless surcoat, ivory sleeves, dark navy short cape, gold heraldic lozenge/crown, belt, dark trousers, stout boots and short sword. Keep these. Keep small squire's oversized steel helmet, ivory/burgundy clothes and simple wooden kite shield with navy panel. Keep both noses EXACT SAME BASE SKIN COLOR as their own cheek and forehead; never red/pink nose or independent nose patch.
The characters currently feel stiff and hard. Rebuild posing with living curved lines, real weight, asymmetry and counter-tilted hips/shoulders. Don't solve it by just billowing a cape behind a rigid torso. The pelvis, belly, shoulders, elbows, knees and head tilt must participate in a unified gesture, while skull/head proportions stay stable and anatomy remains solid.
MAIN TOP55% two full body sprites, side-view3/4 facingright, feet on same baseline, same logical pixel size. King eventual96x96 frame,70-76px body; squire64x64 frame,40-44px body. King giant pear-like, belly projecting, chest and shoulders tipped back, pelvis shifted under the supporting foot, short legs at DIFFERENT bends and one heel rolling into a waddling step. One elbow soft and low with sword held outside silhouette, other arm bent hand near belt, broad soft cloth sleeves compressed at elbows. His navy cape drapes in one heavy smooth cluster curve, belly cloth has only meaningful tension folds. Relaxed convincing off-center volume, not a flat symmetrical round balloon.
King facial identity: broad fleshy double-chin face, auburn sideburns, heavy offset eyelids, small eyes, medium rounded SAME-SKIN nose, uneven delighted smug tooth-block smile with just one small gap. Not generic identical heroic chibi. Chin lifted, eyebrows relaxed differently. Humor from ridiculous confidence in a physically awkward body.
SQUIRE: dutiful apprehensive little adult, compact torso curving behind his shield, oversized low-brim helmet angled slightly with his head, one knee bent inward and one foot stepping to brace. Raised shield tilted diagonally, BOTH arms bend to support weight, lower face visible above/behind edge. Tiny worried mouth with one front tooth and short same-skin nose. He checks the king with his eyes while body anticipates danger. Clear negative space between shield and nose, no impossible wrist or floating shield. Dark hair under helmet remains present.
MIDDLE20% four smaller motion KEY POSES, at a common smaller integer zoom: king winds up his short sword with torso rotation/belly counterweight, king follow-through with bent front knee and lagging cape, squire leaning into shield block with shoulders/knees in one C-curve, squire recoiling a little from impact with feet catching the load and SAME HELMET/SHIELD/HAIR INTACT. Distinct articulated poses, not whole-sprite rotations/translations.
BOTTOM25% two SIX-HEAD expression strips normal, focus, fear, hit, hurt, victory, row names "REI" and "ESCUDEIRO", no column text. Each skull/crown/helmet/nose/hair/sideburn silhouette keeps permanent identity. Expressions coordinate brow, lids and cheeks with mouth. King normal smug contentment, focus affronted command, fear a false brave smile with uneasy eyes, hit indignant pain, hurt proud exhaustion, victory enormous public grin. Squire normal wary duty, focus anxious determination, fear alarm, hit closed-eye bracing and tiny clenched mouth, hurt weary lower lip, victory surprised relieved small bucktooth smile. Don't stamp the same mouth on both. Preserve all sideburns/hair in hit and hurt, never paint mouth over them. No random pink skin patches or bruises.
PIXEL ART: same moderately detailed low-res craft as reference, crisp equal square clusters within each study, clean dark contour, two or three purposeful tones/material, good joined shapes and readable folds. No rigid vector-like mannequin, no overly simplified huge-block pass, no high-resolution smooth painting, antialias, paper grain or noisy tiny textures. Plain solid cool-gray board, spare pixel title "EMPIRE - REI E ESCUDEIRO", only title and row names as text.
```

### Nia e bardo

```text
Use case: stylized-concept. Refine EMPIRE Nia and bard into more fluid, individual, appealing pixel-art characters.
Reference supplies identity and preferred moderate detail. Keep Nia an adult Black empress with compact natural hair, low circlet, ivory sleeves, dark vest, short rust-red cape/sash, dark trousers, sturdy boots and TWO short functional hatchets. Keep the approved bard's floppy ochre feather hat, round lute, ivory sleeves/burgundy vest and small back-mounted banner. Noses must always use SAME BASE SKIN COLOR as each person's cheek/forehead, never a separate red or pink patch.
The current body designs feel stiff. Redraw poses from a continuous LINE OF ACTION and counter-tilted hips/shoulders, naturally bent limbs and clear supporting foot. Keep skull volumes unchanged, no squash/stretch of heads. Full body acting should feel like a lively game sprite caught between movements, not a rigid cutout or a balanced symmetrical catalogue stance.
TOP55% two full-body main sprites at SAME pixel scale/baseline. Both eventual64x64 frames with weapons/flag margins. NIA LEFT: a compact forward coiled S-curve, one knee deeply soft and one leg pushing, hips tipped opposite shoulders, head tilted toward next action, small provocative smile and narrow precise eyes. One hatchet hand back/low behind her hip, other near shoulder, elbows distinctly different, arms never mirrored. Weight believable, shoulders and abdomen turn gently; keep face and weapon separated. Cape and sash form ONE flowing backward curve instead of a flat triangular slab. Her upright head shape remains adult and distinctive, not anime.
BARD RIGHT: chest proudly lifted, head leaning back into song, curved back with hips forward and knees soft, one heel just lifted, one supporting planted foot. Lute held convincingly, fretting hand on neck, strumming hand near soundboard, round belly counterbalances the lute. Hat, feather and small banner follow curved lines with delayed motion; banner stays within eventual64px envelope. Overall triangular silhouette has spring and wit. Mouth joyfully open, eyes closed, long SAME-SKIN nose and different rounded face from Nia.
MIDDLE20% four smaller but equally detailed KEY POSE studies at common smaller integer zoom. Nia1 anticipation crouch with torso twist and hatchets clearly held, Nia2 quick sweeping hatchet strike with torso/hips turning and ONE clean pixel arc, cape lagging behind. Bard1 strumming with his whole body leaning into lute, Bard2 enthusiastic song with head raised and one leg lightly lifting, still balanced. Do not merely rotate or translate the whole sprite; genuinely articulate shoulders/elbows/knees/hips, preserve anatomical volumes.
BOTTOM25% two six-head expression rows. Exact same permanent head shapes, hair/hat, nose silhouettes, side hair and face identities across six states normal, focus, fear, hit, wounded, victory. Nia mostly precise horizontal/asymmetric mouth acting, low confident brow and short nose; bard more vertical vocal mouth, rounded cheek, longer nose and unequal brows. Nia fear is vigilant tension and lips pulled back, not a generic circular gasp; bard focus is musical concentration with eyes partly closed and small O mouth, not anger. Pain comes through eyebrows/lids/cheeks plus a small appropriate mouth; keep natural upper lip/cheek anatomy attached. Nia victory playful asymmetric smile, bard victory a sung laugh. No random bruises or hair disappearing in hit states, no head-size drift or changing tooth identity.
PIXEL MEDIUM: moderately detailed low resolution game pixel art, connected square clusters, one consistent native pixel scale in each study, clean dark contour and two-three purposeful tones/material. Retain useful fabric folds and leather blocks, no oversimplified giant-block pass, no smooth high-res digital painting, antialias, grain, noisy detail or tiny eye pixels beneath the common grid. SOLID muted cool-gray background, spaced layout, pixel title only "EMPIRE - NIA E BARDO". Row names "NIA" and "BARDO"; no tiny column labels or other text.
```

### Arqueiro e intendente

```text
Use case: stylized-concept. Substantial pose and design refinement of the EMPIRE archer emperor and his arrow supplier.
Reference image supplies identity, outfit and preferred MODERATE DETAIL PIXEL ART. Keep olive/teal/ivory archer, crown over hood, tall slender face and long SAME-SKIN nose; keep supplier rust cap, olive vest, huge quiver, square face and thick moustache. Do not make their noses pink/red. Both noses share exact base skin color with cheek/forehead.
The user says all designs feel too STIFF. Rebuild the body posing with a strong continuous curved line of action, asymmetrical shoulder/hip angles, bent active elbows and knees, natural weight over a clear supporting foot. Show their personality in the WHOLE BODY. No straight upright paper dolls or mirrored arms. Keep solid anatomy and the same head/body proportions across poses.
MAIN TOP55%: archer at left, supplier at right, same ground and same underlying sprite pixel size. Archer eventual96x96 frame, body about68 logical pixels tall; supplier64x64, body40px, overall quiver52px. Archer has a languid forward S-curve: one leg carries weight, the other heel lifted, pelvis set back and long neck/head angled with smug concentration. Bow held diagonally OUTSIDE face silhouette, one hand clearly gripping central handle, other hand reaching back toward quiver, one elbow higher than other. His short teal cape falls in a curve with gentle follow-through. Preserve the functional continuous bowstring connecting bow tips, no impossible grips.
Supplier is pulled backwards a little by his oversized load, curved back and one knee soft, shoulders angled, one foot stepped forward, arm bent with open palm demanding payment; other arm tucks a useful arrow bundle to his side. His tired skeptical expression and sagging moustache contrast with archer's self-importance. Keep quiver large without tiny individually rendered feather hairs; no equipment covering his face.
MIDDLE20% four SMALL dynamic key poses at a common smaller integer zoom: 1archer drawing bow, aiming one eye with drawing hand at jaw and torso twisted; 2archer release/follow-through, bow grip stable, arrow no longer on string; 3supplier struggling to balance quiver while reaching for arrows, expressive bent-knee counterbalance; 4supplier recoiling from a hit with torso curved and feet catching weight. Real articulated poses, not identical sprites translated/rotated. No impact injuries or blood.
BOTTOM25% two SIX-HEAD expression rows, no column labels, row names only "ARQUEIRO" and "INTENDENTE". Order normal, focus, fear, hit, wounded, victory.
CRITICAL FACIAL HAIR CONTINUITY: the supplier's thick brown moustache is PERMANENT ANATOMICAL IDENTITY and remains completely present in ALL SIX HEADS AND ALL FULL BODY POSES, including the FOURTH HIT HEAD and recoil body pose. Maintain TWO CLEAR DARK LOBES with visible roots directly under nose and both tips. His lips and jaw move UNDER this moustache; the mouth never paints over or erases it. For hit, close the eyes, tighten the cheeks, tip moustache lobes with the upper lip and make the SMALL open mouth BELOW its center. Do not replace the moustache with a bare upper lip, teeth, skin fill or black mouth. Keep scalp hair and sideburns present too. Do not invent a new chin beard.
Supplier face remains square, low eyebrows, big short same-skin nose, permanent moustache and little chin. His delight is a subtle corner smile under moustache, not generic huge grin. Archer face stays long and narrow with a small pointed chin and half lids; his focus is aiming, his fear restrained doubt, hit a brief wince, victory a small vain smirk. Do not give both identical emotions/eye shapes. Skull/nose/hood/cap don't change between expressions.
Rendering: clean native-style pixel art with deliberate equal square clusters and strong readable contours, moderate 2-3 tones/material, purposeful connected folds, no airbrushed painting, grain, gradients, noisy fabric or mixed high-resolution facial pixels. Match detail of reference, not a giant-block minimalism pass. Spacious plain cool-gray board. Pixel title "EMPIRE - ARQUEIRO E INTENDENTE". No other text besides title and two row names.
```

### Correção localizada do bigode

```text
Precise local correction to the attached sheet. Change ONLY the FOURTH small INTENDENTE head from the left in the BOTTOM ROW (the head with closed eyes and white clenched teeth). Everything else stays unchanged.
That head has wrongly lost part of its BROWN MOUSTACHE. Restore the SAME LARGE SOLID BROWN MOUSTACHE as the FIRST head of the bottom row, aligned directly beneath the nose, including BOTH thick lobes and BOTH drooping tips. It MUST entirely cover the upper lip. In this hit expression, the mouth is CLOSED AND COMPLETELY HIDDEN BEHIND THE MOUSTACHE. ERASE ALL WHITE TEETH in this fourth bottom head. Pain is communicated by its already-squeezed eyes, eyebrow and cheek only. There must be NO visible white teeth or bare peach upper lip under the nose in that head.
Copy the identity and coverage of the first head's moustache, not a generic black mouth shape. Keep its nose SAME SKIN COLOR, cap, hair, head outline and scale. Do not change any of the other eleven heads, any body pose, the title or the palette.
```

### Imperador sombrio e dançarina

```text
Use case: stylized-concept.
Asset: substantially refined EMPIRE character concept board, focused on the unsettling armored emperor and the startling tenderness of his flower-field rest.
Input image is the current design reference. The user LIKES EVERYTHING ABOUT THE DANCER: preserve her exact recognizable face, small same-skin nose, copper bun, ivory sleeves, sage tunic, orange ribbons, dark leggings, boots, and graceful personality. Do not redesign her, add weapons or change her role.
REDESIGN THE EMPEROR DEEPLY. The previous rounded shiny silver suit looked too friendly and toy-like. Make him a dark, haunting, frightening original emperor with a heavy living silhouette, still part of this caricatured medieval PIXEL ART game. Closed armored giant, 128x128 eventual native frames, around 95 pixels standing height; dancer64x64,44 pixels body height. SAME pixel size and world scale for both.
NEW DESIGN: near-black blued iron and charcoal-purple shadow masses with selective cold slate highlights. Very broad uneven angular shoulder plates framing an unusually small, sunken, elongated CLOSED helmet. The faceplate has a narrow T-shaped recessed black opening, no visible human face, no smile or white cartoon eyes, no glowing red eyes. Crown of tarnished iron/bronze with three thin irregular points, fused visually to the helmet silhouette without looking like devil horns. Torso a thick forward-leaning wedge, heavy gauntlets, jointed knees, large grounded boots. One shoulder slightly higher, pelvis and shoulders counter-tilted, head thrust forward under the shoulders: disturbing WEIGHT and presence, not a straight mannequin. Dark desaturated oxblood cape hangs in an uneven curved fall and touches ground when sitting; no bright ivory fur collar, polished gold piping or broad bright silver highlights. Keep armour readable in THREE large connected flat values, with only a few meaningful nicks, not noisy gothic filigree or spikes everywhere. No skull motifs, gore or new weapon. Empty hands.
The scary effect comes from a looming broken line of action, severe closed visor, dark negative space and heavy asymmetry. Solid anatomy and balanced support. Armor plates articulate around elbow/knee joints; do not turn the torso into a rigid square.
Composition: wide refined pixel-art board on a plain muted mid-gray background, sparse pixel title "EMPIRE - SOMBRA E FLORACAO". Main top 62%: LEFT full emperor STANDING with a threatening, slightly forward stalking counterpose and one lowered gauntlet open, shoulders angled and one foot carrying weight. CENTER the EXACT SAME emperor now SITTING DIRECTLY ON THE FLAT EARTH, armored butt on soil, knees naturally bent forward/outward, boots before him, gauntlets relaxed on knees, shoulders settled and helmet bowed. No stump, rock, seat, throne, bench or raised mound. Keep identical iron crown, helmet, plates, cape and shadow palette across standing/seated versions.
Around the seated emperor a low horizontal MEADOW SPREADS OUT: vibrant but small pink/magenta, golden yellow, pale blue and cream FLOWERS on green stems, growing from earth beside and before his feet. More than two clumps: a readable modest field spreading sideways, with gaps to show body-ground contact. Strong poetic contrast of threatening dark giant and delicate colorful life. He stays dark and frightening even at rest; don't make his armor cute or recolor it when flowers appear. No luminous aura. Flowers and character use SAME pixel grid.
RIGHT show the original dancer UNCHANGED IN DESIGN in her light balanced dancing pose, smaller than the giant, on the same ground, warm lively counterpoint to the dark figure. Her nose remains same skin base color.
Bottom 30% four smaller storyboard poses at a shared smaller integer zoom: the SAME dark giant lowering his hips (one hand bracing); seated on bare earth; seated with tiny green sprouts and colored buds; same seated posture with the colorful meadow now open. Real weight transfer from pose1to2, body stable from2to4. Keep every plate/crown/cape shape recognizable. Tiny labels "DESCER", "SENTAR", "BROTAR", "FLORIR".
MEDIUM: deliberate LOW RESOLUTION PIXEL ART, like sprites drawn at native resolution then nearest-neighbor enlarged. Keep the preferred moderately detailed quality of the input, but everything is built from clean equal square clusters, dark crisp contours, no smooth illustration lines, gradients, airbrush, tiny texture dots, paper grain or high-resolution face details. Natural flowing poses with clear negative spaces, not stiff cutout limbs.
```

