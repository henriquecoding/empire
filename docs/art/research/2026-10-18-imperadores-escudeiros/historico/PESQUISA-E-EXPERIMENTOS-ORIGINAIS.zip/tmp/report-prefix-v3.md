# Empire — imperadores e escudeiros: pesquisa aplicada e revisão dos conceitos

**Henrique Passos · 18 de outubro de 2026 · Revisão 3**  
**Estado:** conceitos revistos para avaliação artística. O ZIP com animações completas continua dependente da aprovação dos desenhos, conforme o pedido original.

Esta revisão substitui a direção visual da primeira entrega. Conserva o contrato de animação e a informação técnica útil do estudo anterior, identifica o que foi corrigido e acrescenta pesquisa específica sobre atuação facial e consistência.

## 1. Direção que passa a orientar a produção

As instruções mais recentes de Henrique prevalecem sobre as propostas anteriores:

- Preservar o **nível de detalhe da primeira revisão do rei**. O ensaio posterior, excessivamente simplificado, não será a referência de acabamento.
- O nariz pertence à mesma rampa de pele do rosto. A sua cor base é a da testa e da bochecha; forma, perfil e sombra definem o volume. Retirar a mancha rosa ou vermelha usada nos ensaios.
- Cada personagem precisa de anatomia facial e atuação próprias. Um mesmo estado de jogo não exige a mesma expressão em todo o elenco.
- O rei usa a proposta de sobrevestimenta vinho, mangas marfim e capa curta azul-escura. A barriga permanece inteiramente coberta e as pernas distinguem-se sob a barra.
- O imperador de armadura **senta-se diretamente no chão**, com o peso apoiado nas nádegas e as pernas relaxadas à frente. A recuperação faz nascer **flores coloridas** junto dele.
- Os acompanhantes e imperadores pequenos terão frames de 64×64. Os maiores podem ter frames superiores, conservando o mesmo pixel de autoria.

A preferência pelo detalhe da primeira versão não constitui aprovação automática dos quatro desenhos. A etapa atual apresenta as correções para essa avaliação.

### 1.1 O que foi apresentado nesta revisão

| Prancha | Conteúdo revisto |
| --- | --- |
| Rei e escudeiro | Roupa vinho/marfim/azul-escuro; nariz no tom da pele; seis expressões para cada um |
| Nia e bardo | Expressões mais precisas de Nia e atuação musical do bardo; narizes revistos; seis estados para cada um |
| Arqueiro e intendente | Arqueiro de atuação contida e fornecedor de bigode e olhar pesado; narizes revistos; legendas incorretas retiradas na conferência |
| Imperador de armadura e dançarina | Imperador sentado no chão com flores rosa, amarelas e azuis; quatro momentos da habilidade; seis expressões da dançarina |

São **42 estudos faciais**, distribuídos pelos sete rostos visíveis, e quatro momentos de atuação corporal/floração para o imperador de elmo fechado. As pranchas são conceitos ampliados. A sua resolução total não certifica o tamanho nem a paleta de um futuro sprite de produção.

Foi acrescentada uma prova técnica independente com 12 amostras faciais em células nativas de 64×64. Ela demonstra o controlo da grelha e das alterações de expressão; não substitui o acabamento preferido nem aprova um desenho final.

## 2. Pesquisa: o que muda concretamente no trabalho

A pesquisa usa artigos dos próprios artistas, materiais de professores de animação e documentação oficial das ferramentas. As dimensões, cores e personalidades propostas para Empire são decisões de projeto, não regras universais extraídas dessas fontes.

### 2.1 Pixel art: detalhe útil dentro de uma resolução definida

Derek Yu trabalha o desenho, a limpeza das linhas e o volume em resoluções concretas. O seu segundo tutorial mostra como tons semelhantes, sombreado que acompanha o contorno e formas rígidas prejudicam a leitura. A aplicação a Empire é conservar o detalhe apreciado, mas concentrá-lo em volumes, dobras essenciais e materiais reconhecíveis [S01–S02].

Saint11 define a construção por grupos de pixels da mesma cor. O detalhe pode existir, mas deve apoiar massas legíveis. A discussão de antialias e banding também impede uma conclusão simplista: suavização manual não é universalmente proibida em pixel art. Neste projeto, a borda do sprite deve funcionar sobre cenários diferentes, sem halo pintado para um fundo específico [S03–S04].

O estudo de SLYNYRD sobre cavaleiros começa pela anatomia sob a armadura e organiza luz e sombra em grupos. Ele distingue explicitamente o detalhe de uma peça estática das exigências da animação. Para Empire, os elementos com maior custo de continuidade — correias pequenas, rebites, dedos, cabelo fragmentado — só entram quando contribuem para o desenho [S10].

**Consequência prática:** manter a riqueza das roupas e da armadura preferidas por Henrique; reduzir ruído e resolver as articulações; não aumentar a resolução dos olhos, dentes ou nariz para esconder problemas de desenho.

### 2.2 Expressão: intenção antes de trocar a boca

Dana Boadway-Masson trata a expressão como resposta do personagem ao que percebe. Isso orienta a pergunta anterior ao desenho: o que este indivíduo está a tentar mostrar ou esconder? O rei pode disfarçar o medo; o escudeiro pode expô-lo imediatamente. São leituras do mesmo acontecimento, com atuação diferente [S13].

Shawn Kelly sublinha que o rosto deve agir como uma unidade. A aplicação em baixa resolução é coordenar o ângulo das sobrancelhas, a abertura das pálpebras e a boca. Uma boca triste colada a olhos de vitória deixa de comunicar a intenção, mesmo que cada elemento isolado esteja bem desenhado [S14].

Os estudos de faces de SLYNYRD reforçam a necessidade de simplificar e posicionar os traços na grelha. São estudos de retratos e estética anime; servem aqui para estudar organização e perfil. Não autorizam importar olhos grandes ou a resolução desses retratos para os sprites pequenos do Empire [S12].

**Consequência prática:** fixar a identidade do rosto e, em seguida, desenhar estados específicos dessa identidade. A boca do bardo é mais vertical e expansiva; a do arqueiro é estreita e contida; o bigode limita a boca visível do intendente.

### 2.3 Consistência: comparar em sequência, não apenas lado a lado

No estudo de personagem em várias direções, SLYNYRD identifica erros de proporção que aparecem quando as vistas são sequenciadas. Também explica como um detalhe atraente numa pose pode criar ruído em movimento. Para Empire, a validação inclui reproduzir a troca de expressões e as poses extremas antes de multiplicar ciclos [S09].

Saint11 discute consistência de resolução, posição e rotação. Aqui, a regra é manter uma grelha de autoria, deslocamentos inteiros nos detalhes do rosto e uma escala comum no mundo do jogo. A ampliação de apresentação não pode criar uma segunda resolução dentro do mesmo sprite [S05].

A documentação de Aseprite fornece ferramentas concretas para a revisão: camadas, quadros, tags, onion skin e cels vinculadas. Estas últimas partilham imagem e posição; exigem atenção para não propagar uma alteração de expressão a quadros que deveriam continuar diferentes [S15–S17].

**Consequência prática:** comparar a silhueta e os pixels de identidade com uma referência fixa, limitar as mudanças à região facial apropriada e rever a expressão no contexto da cabeça e do corpo em movimento.

### 2.4 Animação: poses fortes e ações que respeitam o jogo

SLYNYRD mostra que quantidade de quadros não equivale automaticamente a energia ou boa leitura. As poses principais e o tempo de exposição continuam decisivos. O estudo lateral de ataques também relaciona arma, postura e resposta ao comando [S06–S07].

O estudo lateral de 2026 parte de um corpo simples e acrescenta equipamento e movimento secundário depois. Essa separação orienta o trabalho de capas, bandeira, aljava e armadura. Não implica acrescentar ao Empire as mecânicas de tiro daquele exemplo [S11].

**Consequência prática:** aprovar corpo, rosto e poses extremas; produzir as ações com os tempos do projeto; ligar o evento de flecha, bloqueio ou recuperação ao momento visual correto.

## 3. Escala, paleta e prova de construção nativa

### 3.1 Frame, corpo e rosto são medidas diferentes

Uma célula de 64×64 pode conter um corpo de 44 px e margem para as machadinhas. O chapéu ou a bandeira não devem tornar o corpo do bardo artificialmente maior. A reserva de margem precisa de ser testada na extensão máxima da ação.

| Personagem | Frame proposto | Altura útil orientadora, em pé | Região orientadora da cabeça |
| --- | --- | --- | --- |
| Rei | 96×96 | 70–76 px | Aproximadamente 22–26 px |
| Escudeiro protetor | 64×64 | 36–44 px | Aproximadamente 14–18 px com elmo |
| Nia | 64×64 | 42–46 px | Aproximadamente 16–20 px com cabelo |
| Bardo | 64×64 | 40–44 px de corpo; conjunto até 56 px | Aproximadamente 18–22 px com chapéu |
| Arqueiro | 96×96 | 64–70 px | Aproximadamente 18–22 px com capuz/coroa |
| Intendente | 64×64 | 35–40 px; conjunto até 54 px | Aproximadamente 16–18 px com gorro |
| Imperador de armadura | 128×128 | 90–98 px | Volume do elmo e encaixe entre ombreiras |
| Dançarina | 64×64 | 40–45 px | Aproximadamente 14–18 px, além do coque |

São metas para a autoria final. A validação compara o elenco na mesma linha de chão e sobre os cenários do jogo. O imperador sentado fica naturalmente mais baixo sem que o seu corpo seja reduzido por escala.

### 3.2 Detalhe moderado e cor do nariz

- Dois tons por tecido como ponto de partida; um terceiro só quando tiver função clara.
- Materiais distinguem-se pela organização das massas: metal com acentos concentrados; linho com dobras amplas; couro com blocos pequenos bem colocados.
- Testa, bochecha e parte iluminada do nariz partilham a cor base de pele do personagem.
- A sombra sob o nariz usa a rampa de pele já existente, sem uma mancha cromática independente.
- Olhos, dentes e fivelas não recebem detalhe abaixo da grelha usada pelo resto do personagem.
- Um ou dois grupos de dentes comunicam melhor a expressão pequena do que uma dentição desenhada individualmente.
- A identidade deve sobreviver em fundo claro e escuro. Contorno e contraste interior são avaliados separadamente.

O detalhe não é medido por uma proibição absoluta de pixels isolados. Um olho ou um acento pode justificar um deles; dezenas de pontos sem função enfraquecem a leitura.

### 3.3 Prova técnica produzida e verificada

A folha EMPIRE-ROSTOS-PROVA-NATIVA-64x64.png contém **12 células de 64×64**, organizadas em seis colunas e duas linhas; o arquivo completo mede **384×128**.

O rei foi construído numa grelha de 24×24 e o escudeiro numa de 16×16, com coordenadas inteiras e paleta explícita. São amostras didáticas independentes, não redução automática das pranchas e não sprites corporais finais.

A conferência dos PNGs exportados verificou:

| Verificação realizada | Resultado |
| --- | --- |
| Quantidade e tamanho das células | 12 células; todas 64×64 |
| Canal alpha | Apenas 0 e 255 |
| Cores opacas por cabeça | 7–8 nesta demonstração |
| Silhueta externa durante a troca de expressão | Idêntica nas seis variantes de cada cabeça |
| Pixels fora das regiões faciais autorizadas | Sem alterações entre estados |
| Nariz na cor base da pele | Verificado nas duas séries |
| Estados distintos | Seis imagens diferentes por cabeça |
| Ampliação de inspeção | 6× por nearest neighbor, com exemplo a 1× |

A prova verifica integridade da construção. A avaliação da beleza, da personalidade e do nível de detalhe continua a depender da revisão artística e das pranchas preferidas.

Arquivos complementares: [folha nativa](EMPIRE-ROSTOS-PROVA-NATIVA-64x64.png) e [painel de inspeção](EMPIRE-PROVA-EXPRESSOES-GRELHA.png).

## 4. Identidade e atuação de cada personagem

Uma expressão original depende da combinação de anatomia, comportamento e situação. A diferenciação não será sustentada apenas pela cor da roupa ou pelo chapéu.

| Personagem | Traços de identidade | Comportamento que orienta o rosto |
| --- | --- | --- |
| Rei | Rosto largo, queixo duplo, pálpebras pesadas, nariz arredondado na rampa da pele | Quer parecer no controlo; exagera a satisfação e tenta esconder o receio |
| Escudeiro | Cabeça mais estreita, nariz curto, olhos sob o elmo, boca pequena e um dente frontal | Antecipa os perigos e esforça-se por cumprir o dever apesar do medo |
| Nia | Mandíbula compacta, maçãs do rosto marcadas, nariz curto, sobrancelhas ativas e olhar estreito | Confiança inquieta e prontidão; desafia antes de hesitar |
| Bardo | Nariz mais longo e curvo, bochechas redondas, queixo menor, boca vertical expansiva | Vive a situação como atuação; ouvir, cantar e perder a voz são estados diferentes |
| Arqueiro | Rosto comprido, queixo fino, nariz longo, pálpebra horizontal e sorriso de canto | Mantém distância e confiança; mira com contenção e procura parecer infalível |
| Intendente | Rosto quadrado, nariz baixo e largo, bigode dominante, sobrancelhas pesadas | Observa o pagamento e mostra impaciência; a satisfação aparece discretamente |
| Imperador de armadura | Elmo fechado; grandes massas de ombros, braços e pernas | O peso e a história aparecem na postura; cansaço, repouso e alívio sem inventar olhos no metal |
| Dançarina | Rosto afunilado, queixo pequeno, nariz curto, coque e sobrancelhas arqueadas | Atenção leve e curiosidade; energia nos gestos, alegria de alívio e vulnerabilidade contida |

Estas escolhas mantêm o mesmo tratamento de caricatura em todo o elenco. A personalidade de Nia vem da atuação, postura e desenho próprio, preservando a sua identidade de mulher negra adulta.

### 4.1 O mesmo estado não produz a mesma cara

| Estado | Rei | Escudeiro | Bardo | Arqueiro | Intendente |
| --- | --- | --- | --- | --- | --- |
| Calma | Satisfação convencida | Atenção nervosa | Escuta e pequeno murmúrio | Segurança distante | Espera pelo pagamento |
| Foco | Ordem contrariada | Determinação tensa | Concentração musical | Olho de mira estreito | Conta e desconfia |
| Medo | Tenta sustentar uma falsa segurança | Alarme evidente e queixo recolhido | Perde o fio da canção | A confiança vacila | Indignação alarmada |
| Golpe | Dor ofendida | Encolhe-se para suportar | Careta curta e boca contraída | Reação oblíqua contida | Resmungo sob o bigode |
| Ferido | Cansaço que procura esconder | Desânimo fatigado | Perde a voz e a energia | Frustração exausta | Resignação |
| Vitória | Grande sorriso público | Alívio surpreso | Canto teatral | Satisfação de canto | Pequeno sorriso lateral |

Nia usa tensão curta e precisa no foco, vigilância no medo, irritação cansada ao ficar ferida e um sorriso provocador na vitória. A dançarina mantém alarmes menores, olhos e lábios mais suaves e uma alegria de alívio.

O estado ferido não será comunicado por pintar o nariz de outra cor. As pálpebras, a boca, o apoio do corpo e os estados já definidos pelo jogo cumprem essa função.

## 5. Método para prevenir e encontrar falhas

### 5.1 Modelo de identidade por personagem

Antes de animar, fixar uma cabeça neutra por vista e registar o seu tamanho, linha dos olhos, perfil do nariz, queixo e ligação ao pescoço. Coroa, elmo e cabelo acompanham essa cabeça. O modelo é confrontado com o corpo e com os companheiros do elenco.

A expressão altera os grupos destinados a sobrancelhas, pálpebras e boca, com eventual acento de bochecha. Não altera involuntariamente a largura do crânio, o número de dentes visíveis, o comprimento do nariz ou o tamanho da coroa. O projeto proíbe squash and stretch da cabeça; a atuação respeita essa regra.

### 5.2 Conferência facial

1. Rever a cabeça neutra sem equipamento a ocultar os seus pontos de referência.
2. Ler cada estado a 1× antes de ampliar.
3. Comparar normal/foco, medo/golpe e ferido/vitória. Cada par precisa de sinais diferentes em mais de uma região facial.
4. Alternar os estados na mesma posição para identificar deriva de volume.
5. Cobrir temporariamente a boca e avaliar olhos/sobrancelhas; depois fazer o inverso. O teste ajuda a localizar dependência excessiva de um único sinal, sem exigir leitura completa de toda a emoção por cada região isolada.
6. Conferir direção das pupilas e intenção do olhar na vista de jogo.
7. Conferir que a sombra do nariz não se transformou numa cor independente.
8. Rever a expressão no corpo inclinado, a andar, a atacar e a receber impacto.

### 5.3 Conferência de movimento e equipamento

| Falha a procurar | Como verificar/corrigir |
| --- | --- |
| Rosto a deslizar sobre a cabeça | Conferir o ponto da cabeça em cada quadro; mover a expressão com esse ponto |
| Cabeça a aumentar numa careta | Comparar máscara externa e medidas com a pose correspondente |
| Cabelo, elmo ou coroa a saltar | Rever sobreposição entre quadros e posições de encaixe |
| Dentes que mudam aleatoriamente | Conservar grupos e espaços de identidade nas aberturas relevantes |
| Olho fora do rosto ou olhar incoerente | Conferir vista de jogo e região disponível sob a pálpebra/elmo |
| Arma a atravessar o rosto | Rever a pose extrema e o espaço entre cabeça, mão e equipamento |
| Troca de mão por espelhamento | Conferir os dois sentidos e documentar a assimetria escolhida |
| Um ajuste a propagar-se a todos os estados | Conferir cels vinculadas antes de editar expressões independentes |
| Tremulação de detalhe | Reproduzir o ciclo na velocidade de jogo, além de percorrer os quadros |
| Cura, dano ou flechas acionados pelo desenho | Conferir a ligação ao evento da simulação; o efeito só apresenta o resultado |

A expressão de impacto é transitória. Ao terminar, o rosto volta ao estado que a personagem realmente tem, incluindo ferido quando aplicável. A produção não deve assumir que qualquer reação regressa sempre ao sorriso neutro.

### 5.4 Critério de conclusão

Um PNG com dimensões certas pode ter desenho ou atuação fracos. Uma prancha bonita pode não conter frames utilizáveis. A entrega de animações precisará passar por integridade dos arquivos, revisão artística e reprodução no jogo. Nenhuma destas camadas substitui as outras.

## 6. Imperador: sentar no chão e fazer nascer flores

Esta revisão elimina o suporte sob o imperador. A capa pode tocar o terreno; não funciona como assento elevado. O corpo mantém o seu volume ao baixar.

### 6.1 Anatomia e peso da ação

- A descida envolve quadril e joelhos; o tronco compensa o peso antes do contacto.
- O apoio termina diretamente no solo, com as pernas à frente e as botas separadas o suficiente para ler a pose.
- As mãos repousam sobre os joelhos e os ombros descem.
- Ombreiras, cotovelos e joelheiras conservam a articulação. Não se comprime toda a armadura como uma peça de borracha.
- O elmo inclina-se com cansaço. Ao recuperar, o alívio é pequeno e corporal.
- Ao levantar, o peso precisa voltar aos pés antes de o corpo completar a subida.

### 6.2 Sequência visual proposta

| Momento | Corpo | Plantas |
| --- | --- | --- |
| Descer | Quadril baixa; joelhos dobram; massa ainda sustentada | Chão livre |
| Sentar | Nádegas assentes; pernas à frente; mãos nos joelhos | Chão livre |
| Brotar | Corpo já estabilizado na pose de repouso | Folhas pequenas e botões em pontos definidos |
| Florir | Mesmo corpo sentado | Flores rosa/magenta, amarelas e azuis com centros claros |
| Recuperar | Respiração e pequeno movimento de repouso | Crescimento concluído; movimento discreto quando necessário |
| Levantar | Transferência de peso e regresso ao apoio | Continuidade visual definida pela duração do efeito |

Os quatro estudos apresentados mostram os primeiros quatro momentos. Eles não são uma folha final com o ciclo completo de levantar.

Como proposta de autoria, a descida pode partir de seis quadros a 10 fps e o repouso usa os oito quadros previstos para heal. O crescimento recebe uma linha de tempo própria. Estes números não alteram a cura ou o tempo da habilidade na simulação.

### 6.3 Construção das flores

- Flores pequenas mas cromaticamente claras: três famílias principais de pétalas, com folhas e caules a sustentá-las.
- Controlo de grupos em vez de pontos coloridos dispersos.
- Botões surgem nos mesmos pontos em que as flores abrem.
- A flor cresce a partir do solo. Não nasce do elmo, de uma luva ou de dentro da armadura.
- A vegetação conserva intervalos em torno de botas e mãos, para não esconder o contacto com o chão.
- As flores pertencem ao efeito do imperador. A pose da dançarina não a transforma na fonte da floração.

### 6.4 Regras para a futura integração

O corpo e a flora são camadas independentes. A referência do efeito é um ponto de chão coerente com a posição do personagem. A origem de apresentação mantém-se estável ao sentar; não é recalculada pelo retângulo aparente do corpo.

O evento de entrada no estado de repouso inicia o efeito uma vez. O loop corporal não deve gerar uma nova camada de flores em cada repetição. O número de elementos e a ordem de crescimento precisam ser estáveis para a mesma execução visual.

Interrupção, saída e nova entrada na habilidade precisam de ser revistas: sem flores duplicadas, corpo a saltar para outra posição, plantas suspensas ou desaparecimento abrupto no meio de um quadro. A persistência das flores e a sua eventual função no mundo continuam decisões de gameplay; o conceito não lhes atribui colisão, recursos, dano ou bónus adicionais.


