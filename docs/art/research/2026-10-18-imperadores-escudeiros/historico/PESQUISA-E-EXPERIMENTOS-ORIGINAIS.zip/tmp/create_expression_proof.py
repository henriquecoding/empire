from pathlib import Path
from PIL import Image, ImageDraw, ImageFont
import json

# A precise construction diagram, authored from integer coordinates.
# No generated image is opened or modified by this script.
OUT = Path('/workspace/scratch/7a5f6b7b5183/output')
OUT.mkdir(exist_ok=True)
C = dict(ink='#241f2b', skin='#efbe88', shade='#c58a60', hair='#97472f',
         hair_shadow='#64302b', gold='#e3b44e', gold_shadow='#a36f35',
         tooth='#f7efce', steel='#a5afbe', steel_shadow='#6d778a', steel_light='#c8d0d9',
         cap='#bc503c', cap_shadow='#84382f', facial_hair='#633c2b')
STATES = ['calmo','foco','medo','golpe','ferido','vitoria']

def king(state):
    im=Image.new('RGBA',(24,24),(0,0,0,0)); d=ImageDraw.Draw(im)
    def p(v,c): d.polygon(v,fill=C[c])
    def r(v,c): d.rectangle(v,fill=C[c])
    p([(5,6),(9,4),(17,5),(19,8),(19,9),(22,9),(23,10),(23,12),(21,13),(21,18),(19,21),(16,23),(9,23),(5,20),(3,16),(3,10)],'ink')
    p([(5,7),(9,5),(14,6),(13,10),(11,11),(10,15),(8,17),(5,18),(4,14),(4,10)],'hair_shadow')
    p([(6,7),(9,6),(13,6),(12,9),(10,10),(9,13),(7,13),(7,16),(5,16),(4,12)],'hair')
    p([(13,6),(17,7),(18,9),(18,10),(22,10),(22,12),(19,13),(20,16),(20,18),(18,21),(15,22),(10,22),(7,20),(6,17),(8,16),(9,14),(9,11),(11,11),(11,8)],'shade')
    p([(13,7),(17,8),(18,10),(22,10),(22,11),(19,12),(19,15),(19,18),(17,20),(14,21),(10,21),(8,19),(7,17),(9,16),(10,14),(10,12),(12,11),(12,9)],'skin')
    r((6,11,7,13),'skin'); r((7,12,7,13),'shade')
    # Fixed crown and silhouette; facial variations remain inside this head.
    p([(6,6),(5,1),(9,3),(12,0),(15,3),(19,1),(18,7)],'ink')
    p([(7,5),(7,3),(9,4),(12,2),(15,4),(17,3),(17,6),(7,6)],'gold_shadow')
    p([(7,3),(9,4),(12,2),(15,4),(17,3),(17,5),(7,5)],'gold')
    if state=='calmo':
        r((13,9,15,9),'ink'); r((14,10,14,10),'ink'); r((18,9,18,10),'ink')
        d.line([(12,16),(13,17),(17,17),(18,16)],fill=C['ink']); r((14,17,16,17),'tooth')
    elif state=='foco':
        d.line([(12,8),(15,9)],fill=C['ink']); r((14,10,14,10),'ink'); r((18,10,18,10),'ink')
        r((13,17,18,17),'ink'); r((17,16,18,16),'ink')
    elif state=='medo':
        d.line([(12,8),(14,7),(15,7)],fill=C['ink']); r((13,9,15,10),'tooth'); r((15,9,15,10),'ink'); r((18,9,18,10),'ink')
        r((12,16,18,18),'ink'); r((13,17,15,17),'tooth'); r((16,18,18,18),'skin')
    elif state=='golpe':
        d.line([(13,9),(15,10),(13,11)],fill=C['ink']); r((18,10,19,10),'ink')
        r((12,16,18,19),'ink'); r((13,17,17,18),'tooth')
    elif state=='ferido':
        r((12,10,15,10),'ink'); r((14,11,14,11),'ink'); r((18,10,18,10),'ink')
        d.line([(12,18),(13,17),(17,17),(18,18)],fill=C['ink'])
    else:
        d.line([(12,10),(13,9),(15,9),(16,10)],fill=C['ink']); r((18,9,18,10),'ink')
        p([(11,15),(14,16),(19,15),(18,19),(15,20),(12,18)],'ink')
        r((12,16,18,17),'tooth'); r((13,18,17,18),'tooth')
    return im

def squire(state):
    im=Image.new('RGBA',(16,16),(0,0,0,0)); d=ImageDraw.Draw(im)
    def p(v,c): d.polygon(v,fill=C[c])
    def r(v,c): d.rectangle(v,fill=C[c])
    p([(4,5),(11,5),(12,8),(14,8),(15,9),(15,10),(13,11),(13,14),(11,15),(6,15),(4,12)],'ink')
    p([(6,6),(11,6),(11,9),(14,9),(14,10),(12,10),(12,13),(10,14),(7,13),(6,11)],'shade')
    p([(7,7),(10,7),(11,9),(14,9),(14,10),(11,10),(11,13),(9,13),(7,12)],'skin')
    r((4,9,5,13),'hair_shadow')
    p([(1,6),(2,3),(4,1),(9,0),(12,2),(14,5),(15,6),(15,7),(2,8)],'ink')
    p([(2,6),(3,3),(5,2),(9,1),(11,3),(13,5),(14,6),(3,7)],'steel_shadow')
    p([(3,5),(4,3),(6,2),(9,2),(11,4),(12,5),(8,5),(5,6)],'steel')
    p([(5,3),(6,2),(8,2),(8,3)],'steel_light')
    d.line([(3,7),(13,6)],fill=C['ink'])
    if state=='calmo':
        r((9,8,9,9),'ink'); r((10,12,11,12),'ink'); r((11,13,11,13),'ink')
    elif state=='foco':
        d.line([(8,8),(10,9)],fill=C['ink']); r((10,12,11,12),'ink')
    elif state=='medo':
        r((8,8,10,9),'tooth'); r((10,8,10,9),'ink'); r((9,11,11,13),'ink'); r((9,11,9,11),'tooth')
    elif state=='golpe':
        d.line([(8,8),(10,9),(8,10)],fill=C['ink']); r((9,12,11,13),'ink'); r((10,12,10,12),'tooth')
    elif state=='ferido':
        r((8,9,10,9),'ink'); r((9,10,9,10),'ink'); d.line([(9,13),(10,12),(11,13)],fill=C['ink'])
    else:
        d.line([(8,9),(9,8),(10,9)],fill=C['ink']); d.line([(8,11),(9,13),(11,12)],fill=C['ink']); r((9,12,9,12),'tooth')
    return im

def supplier(state):
    im=Image.new('RGBA',(20,20),(0,0,0,0)); d=ImageDraw.Draw(im)
    def p(v,c): d.polygon(v,fill=C[c])
    def r(v,c): d.rectangle(v,fill=C[c])
    p([(3,6),(7,4),(13,4),(15,7),(15,8),(18,8),(19,9),(19,10),(16,11),(16,16),(14,19),(5,19),(2,16),(2,10)],'ink')
    p([(4,7),(12,5),(14,8),(18,9),(18,10),(15,11),(15,16),(13,18),(6,18),(3,15),(3,10)],'shade')
    p([(6,7),(12,6),(13,8),(15,9),(18,9),(18,10),(14,11),(14,16),(12,17),(7,17),(4,15),(4,11)],'skin')
    r((3,8,4,14),'hair_shadow'); r((4,10,5,11),'shade')
    p([(1,7),(2,3),(8,0),(13,1),(17,4),(17,6),(14,8),(3,8)],'ink')
    p([(2,6),(3,3),(8,1),(13,2),(16,4),(16,6),(13,7),(3,7)],'cap_shadow')
    p([(3,5),(4,3),(8,2),(12,3),(15,4),(13,5),(5,6)],'cap')
    if state=='calmo':
        r((8,8,11,8),'ink'); r((10,9,10,9),'ink'); r((14,8,14,9),'ink')
    elif state=='foco':
        d.line([(8,8),(11,9)],fill=C['ink']); r((10,10,10,10),'ink'); r((14,9,14,9),'ink')
    elif state=='medo':
        r((8,9,11,10),'tooth'); r((11,9,11,10),'ink'); r((14,8,14,9),'ink'); r((11,15,13,17),'ink')
    elif state=='golpe':
        d.line([(8,8),(10,9),(8,10)],fill=C['ink']); r((14,9,14,9),'ink')
    elif state=='ferido':
        r((8,9,11,9),'ink'); r((10,10,10,10),'ink'); r((14,9,14,9),'ink'); r((11,17,13,17),'ink')
    else:
        r((8,9,11,9),'ink'); r((10,10,10,10),'ink'); r((14,8,14,9),'ink'); r((13,16,14,16),'ink'); r((13,16,13,16),'tooth')
    # Persistent upper-lip hair is composited AFTER the mouth. It cannot be erased by teeth.
    p([(8,13),(10,11),(12,12),(14,11),(17,12),(17,15),(15,14),(13,14),(11,14),(8,15)],'facial_hair')
    return im

rows=[[king(s) for s in STATES],[squire(s) for s in STATES],[supplier(s) for s in STATES]]
NAMES=['rei','escudeiro','intendente']
strip=Image.new('RGBA',(384,192),(0,0,0,0))
for row, heads in enumerate(rows):
    for col, head in enumerate(heads):
        # Each 64x64 cell has the same anchor: top-left of head at (20,20).
        strip.paste(head,(64*col+20,64*row+20),head)
native=OUT/'EMPIRE-ROSTOS-PROVA-NATIVA-64x64.png'; strip.save(native)

# Diagram typography is separate from sprite pixels. All sprite enlargement is nearest.
board=Image.new('RGB',(1420,905),'#eeeae1'); q=ImageDraw.Draw(board)
font='/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf'
bold='/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf'
F=lambda n,b=False:ImageFont.truetype(bold if b else font,n)
q.text((40,26),'EMPIRE · prova técnica de expressões',font=F(30,True),fill=C['ink'])
q.text((40,74),'Amostras de construção na grelha; os conceitos de figurino estão nas pranchas.',font=F(18),fill='#57515e')
for j,s in enumerate(STATES): q.text((238+j*192,127),s.upper(),font=F(16,True),fill=C['ink'])
for row, heads in enumerate(rows):
    top=175+row*225
    q.text((40,top+16),NAMES[row].upper(),font=F(20,True),fill=C['ink'])
    q.text((40,top+51),f'{heads[0].width} × {heads[0].height} px',font=F(17),fill='#57515e')
    q.text((40,top+79),'ampliação 6×',font=F(16),fill='#57515e')
    for col,head in enumerate(heads):
        x=236+192*col
        q.rectangle((x-8,top-8,x+159,top+155),fill='#d9d5ce')
        board.paste(head.resize((head.width*6,head.height*6),Image.Resampling.NEAREST),(x,top),head.resize((head.width*6,head.height*6),Image.Resampling.NEAREST))
        board.paste(head,(x,top+173),head)
        q.text((x+36,top+176),'1×',font=F(13),fill='#57515e')
q.text((40,858),'Nariz na cor da pele; bigode preservado também no golpe. Os exemplos são amostras técnicas.',font=F(17),fill=C['ink'])
preview=OUT/'EMPIRE-PROVA-EXPRESSOES-GRELHA.png'; board.save(preview)

# Validate exported bytes, palette/alpha, uniqueness and the fixed non-facial areas.
check=Image.open(native).convert('RGBA')
assert check.size==(384,192)
assert set(check.getchannel('A').getdata())=={0,255}
checks=[]
for row,heads in enumerate(rows):
    encoded=[]
    base=heads[0]
    for col,head in enumerate(heads):
        cell=check.crop((64*col,64*row,64*(col+1),64*(row+1)))
        assert cell.size==(64,64)
        exported=cell.crop((20,20,20+head.width,20+head.height))
        assert exported.tobytes()==head.tobytes()
        # Crowns/helmets, hair and alpha silhouette are invariant.
        assert head.getchannel('A').tobytes()==base.getchannel('A').tobytes()
        for y in range(head.height):
            for x in range(head.width):
                inside_face=(11<=x<=19 and 7<=y<=20) if row==0 else ((8<=x<=11 and 8<=y<=13) if row==1 else (8<=x<=14 and 8<=y<=17))
                if not inside_face: assert head.getpixel((x,y))==base.getpixel((x,y))
        nose=[(21,10),(13,9),(17,9)][row]
        assert head.getpixel(nose)==(*tuple(int(C['skin'][i:i+2],16) for i in (1,3,5)),255)
        if row==2:
            hair_color=(*tuple(int(C['facial_hair'][i:i+2],16) for i in (1,3,5)),255)
            for hy in range(head.height):
                for hx in range(head.width):
                    if base.getpixel((hx,hy))==hair_color: assert head.getpixel((hx,hy))==hair_color
        encoded.append(head.tobytes())
        checks.append({'personagem':NAMES[row],'estado':STATES[col], 'cores':len({p for p in head.getdata() if p[3]}),'bbox':head.getbbox()})
    assert len(set(encoded))==6
(OUT/'expression-proof-validation.json').write_text(json.dumps({'cells':18,'cell_size':[64,64],'alpha':[0,255],'fixed_head_silhouette':True,'fixed_non_facial_pixels':True,'nose_uses_base_skin':True,'supplier_moustache_preserved_all_states':True,'samples':checks},ensure_ascii=False,indent=2))
print(json.dumps({'native':str(native),'preview':str(preview),'cells':18,'checks':'passed'},ensure_ascii=False))
