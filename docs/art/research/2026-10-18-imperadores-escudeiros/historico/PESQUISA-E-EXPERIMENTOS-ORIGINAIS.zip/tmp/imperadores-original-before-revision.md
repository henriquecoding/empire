# Empire — imperadores e escudeiros: pesquisa, conceitos e contrato de animação

**Henrique Passos · 18 de outubro de 2026**  
**Estado:** conceitos apresentados para aprovação. As animações completas e o ZIP pertencem à etapa seguinte, após a aprovação pedida pelo autor.  
**Base consultada:** main de [henriquecoding/empire](https://github.com/henriquecoding/empire), commit [0c351775e2c569e83fc746ca339202753cd203ae](https://github.com/henriquecoding/empire/commit/0c351775e2c569e83fc746ca339202753cd203ae).

## 1. O que foi entregue nesta etapa

Foram geradas cinco pranchas de conceito:

1. Rei barrigudo e escudeiro do escudo, com poses de espada e proteção.
2. Nia e bardo porta-estandarte, com poses de machadinhas e execução musical.
3. Imperador Arqueiro e intendente das flechas, com poses de tiro e serviço.
4. Imperador de armadura completa e escudeira dançarina, como conteúdo desbloqueável futuro.
5. Comparação dos oito personagens, com uma faixa de silhuetas.

As quatro pranchas de duplas exploram identidade e intenção de movimento. A comparação conjunta serve para discutir massa, altura e diferenciação.

**Os números inscritos nas imagens são dimensões propostas para os futuros frames. As pranchas são imagens de conceito ampliadas, não PNGs individuais já certificados como 64×64, 96×96 ou 128×128.** A aprovação fecha a direção visual; a autoria e a verificação dos sprites nativos continuam sendo uma etapa concreta de produção.

Não foi produzido nem anunciado um ZIP de animações nesta fase. Também não houve alteração do código ou publicação de arte na main.

## 2. O que a main atual determina

A consulta ao projeto foi necessária para preservar funções já decididas e evitar que a aparência inventasse novas classes.

| Personagem | Regra atual que orienta o desenho |
| --- | --- |
| Rei | Grande, lento, defensivo, golpe curto; acompanhado por escudeiro que protege com escudo e evolui para combate |
| Nia | Imperatriz negra, pequena e rápida, ataques curtos e frequentes; o serviço musical pertence ao seu bardo |
| Imperador Arqueiro | Tiro manual, marca e sangramento; precisa de munição paga |
| Escudeiro do Rei | Sua proteção e equipamento têm recursos e estados visíveis |
| Bardo da bandeira | Recebe ordens pagas para encantar e incentivar; evolução para Maestro |
| Escudeiro das flechas | Uma moeda compra seis flechas na regra atual; a forma evoluída também dispara |
| Quarto imperador | Grande, completamente armado, aparência obscura e passado triste; recupera vida sentado e faz nascer vegetação |
| Escudeira do quarto imperador | Dança para aumentar força; a evolução acrescenta abrandamento dos inimigos |

Os três primeiros são os perfis iniciais. O quarto está decidido como conceito futuro na Q-205; nome final, números e implementação permanecem em UN-33. O desenho dele não o transforma numa quarta escolha inicial já disponível.

A companhia atual é formada depois da fundação, usando uma pessoa disponível e sete moedas. A evolução conjunta por feitos de batalha está documentada na main. As imagens não devem sugerir que os acompanhantes aparecem gratuitamente no primeiro segundo da campanha.

O plano antigo de 02/10 foi lido como histórico. Para regras modificadas depois, prevalece a fonte atual: por exemplo, a reposição do Arqueiro agora é de **seis flechas por moeda**, não os lotes exploratórios do documento antigo.

### Referências do próprio projeto

- [Imperadores, companhias e desbloqueios](https://github.com/henriquecoding/empire/blob/0c351775e2c569e83fc746ca339202753cd203ae/docs/design/08-imperadores-companhias-e-desbloqueios.md)
- [Animation Bible](https://github.com/henriquecoding/empire/blob/0c351775e2c569e83fc746ca339202753cd203ae/docs/art/ANIMATION_BIBLE.md)
- [Asset Bible](https://github.com/henriquecoding/empire/blob/0c351775e2c569e83fc746ca339202753cd203ae/docs/art/ASSET_BIBLE.md)
- [Guia de expressões](https://github.com/henriquecoding/empire/blob/0c351775e2c569e83fc746ca339202753cd203ae/docs/art/EXPRESSION_GUIDE.md)
- [Autoridade das referências](https://github.com/henriquecoding/empire/blob/0c351775e2c569e83fc746ca339202753cd203ae/docs/art/REFERENCE_AUTHORITY.md)
- [Perfis dos monarcas](https://github.com/henriquecoding/empire/blob/0c351775e2c569e83fc746ca339202753cd203ae/data/source/monarchs.csv)

**Vercel:** a conexão disponível não localizou o projeto Empire nem o deployment informado pelo README. A consulta pública ao dossiê também falhou. A análise técnica desta etapa baseia-se no commit acima; não constitui um playtest da versão publicada.

## 3. Pesquisa aplicada: desenhar para pixels e para movimento

A pesquisa concentrou-se em fontes de artistas que explicam seus próprios processos e na documentação oficial das ferramentas. A tabela diferencia o princípio observado da escolha proposta para Empire. Tamanhos, personalidades e paletas abaixo são decisões deste projeto, não regras universais.

| Tema | Achado relevante | Aplicação proposta |
| --- | --- | --- |
| Massas de cor | Saint11 começa por grupos grandes e refina; pixels isolados frequentemente criam ruído [S01] | Separar cabeça, tronco, mãos, pernas e objeto principal antes de desenhar correias, dentes e fivelas |
| Desenho animável | O estudo de personagem de SLYNYRD mostra que detalhes atraentes numa pose podem tornar-se ruído noutra [S06] | Validar repouso, perfil e pose extrema de ataque antes de fechar o modelo |
| Anatomia sob equipamento | No estudo de cavaleiros, SLYNYRD constrói o corpo antes da armadura [S08] | Elmo, ombreiras e barriga devem esconder uma estrutura que ainda se articula de maneira compreensível |
| Cor | Saint11 organiza contraste por valor, saturação e relações de temperatura [S03] | Dar a cada dupla uma massa dominante distinta, conservando neutros e materiais comuns |
| Bordas | O excesso de suavização e as faixas paralelas de tons podem enfraquecer a leitura [S02] | Contorno de um pixel e sombreamento curto; avaliar curvas e diagonais no tamanho nativo |
| Animação | Poses fortes e duração dos quadros importam mais do que multiplicar intermediários [S04] | Definir contato, passagem, antecipação, ação e recuperação antes de polir |
| Ataque lateral | Postura, equilíbrio da arma, trajetória e resposta ao comando precisam funcionar juntos [S05] | A espada pesada, as machadinhas e o arco recebem coreografias próprias |
| Assimetria | Ataques em diferentes direções exigem atenção à mão da arma [S07] | Registrar mão dominante e posição de aljava, escudo e bandeira; revisar a leitura de ambos os lados |
| Revisão de quadros | Onion skin permite comparar o quadro atual aos anteriores e seguintes [S13] | Procurar deriva da cabeça, variação involuntária de volume e pés instáveis |
| Exportação | Aseprite separa ciclos em tags e exporta folhas e dados de regiões/pivots [S09–S12] | Entregar nomes, durações, regiões e origem dos pés junto dos PNGs |
| Renderização | Godot distingue amostragem nearest de linear [S14] | Usar nearest para a arte nativa; confirmar a escala final na cena, além da configuração do filtro |

O método de estudo de rotação de SLYNYRD foi consultado para consistência de volume. Empire continua sendo um jogo lateral: isso não cria uma exigência automática de oito direções animadas.

### Ordem de autoria

1. Preencher a silhueta e distinguir o personagem pela forma.
2. Marcar esqueleto simples: cabeça, ombros, cotovelos, quadril, joelhos e contato dos pés.
3. Fixar proporção da cabeça e tamanho das mãos em pixels.
4. Distribuir poucas massas claras e escuras.
5. Construir a arma ou objeto com empunhadura funcional.
6. Desenhar rosto e um detalhe de identidade que sobreviva à distância.
7. Testar perfil, repouso e maior extensão do ataque.
8. Fechar cores, camadas e envelope.
9. Animar as poses principais e depois os intermediários.
10. Conferir continuidade de volume, trajetória e apoio no chão.

A caricatura deve surgir da massa corporal, postura, expressão e relação entre os dois personagens. O acabamento precisa preservar esses sinais ao reduzir a atenção disponível durante o jogo.

## 4. Contrato proposto de escala

**64×64 é o tamanho do frame dos pequenos, incluindo margens e acessórios. Não é a obrigação de todos os corpos ocuparem 64 pixels de altura.**

| Personagem | Frame proposto | Altura útil orientadora | Pivot proposto | Margem a resolver |
| --- | --- | --- | --- | --- |
| Rei | 96×96 | Cerca de 70–76 px com coroa | (48, 88) | Barriga, capa e extensão da espada |
| Escudeiro do escudo | 64×64 | Cerca de 36–40 px de corpo | (32, 56) | Escudo e recuo sem recortar mãos |
| Nia | 64×64 | Cerca de 42–46 px de corpo | (32, 56) | As duas machadinhas nas poses extremas |
| Bardo | 64×64 | Cerca de 40–44 px de corpo; conjunto até cerca de 54–56 px | (32, 56) | Chapéu, instrumento e bandeira dentro do frame |
| Arqueiro | 96×96 | Cerca de 64–70 px com coroa | (48, 88) | Arco, cotovelo da puxada e aljava |
| Intendente | 64×64 | Cerca de 35–39 px de corpo; conjunto até cerca de 52–54 px | (32, 56) | Flechas e gesto de entrega |
| Imperador de armadura | 128×128 | Cerca de 90–98 px | (64, 120) | Ombreiras, passada e pose sentada |
| Escudeira dançarina | 64×64 | Cerca de 40–45 px de corpo | (32, 56) | Braços abertos e caudas do tecido |

São metas de autoria para aprovação, não medições extraídas das pranchas. O modelo final será ajustado dentro do frame de cada personagem.

A Asset Bible atual apresenta telas padrão maiores como proposta, inclusive 96×96 para ofícios e 128×128 para monarcas. O pedido de 18/10 estabelece agora 64×64 para acompanhantes e imperadores menores. A futura produção deve registrar essa atualização sem esticar os pixels dos pequenos para fazê-los parecer maiores.

### Relações que devem sobreviver a todas as poses

- O rei tem o maior volume abdominal; o Arqueiro tem a linha mais longa e estreita.
- Nia é pequena, adulta e ágil, sem parecer uma versão reduzida do rei.
- Escudeiro e intendente são menores que os seus patronos, mas reconhecíveis pelas mãos, postura e equipamento.
- A altura da bandeira não equivale à altura física do bardo.
- A armadura do quarto imperador cria massa por largura, ombreiras e postura, além da altura.
- Todos usam o mesmo pixel de autoria; a diferença vem de quantos pixels formam o corpo.

### Regras gráficas comuns

- Pixel nativo de personagem: 1×1.
- Contorno exterior: um pixel preto, conforme a gramática atual do projeto.
- Dois tons por material como base.
- Paleta de trabalho compartilhada; escolher um subconjunto pequeno por personagem.
- Meta inicial de aproximadamente 12–18 cores visíveis por sprite, a ajustar quando materiais compartilharem tons. Esse intervalo é proposta de produção.
- Acentos fortes concentrados em rosto, coroa, arma e objeto de serviço.
- Espaço negativo entre mãos, rosto e equipamento.
- Sem dithering decorativo no corpo.
- Ampliações para revisão em fatores inteiros.
- Efeitos de alcance, notas musicais, impacto e vegetação podem ocupar camadas próprias; o frame corporal pequeno permanece 64×64.

## 5. Direção das quatro duplas

### 01 — Rei e escudeiro: confiança versus preocupação

**Rei:** silhueta de pera muito larga, pernas curtas, barriga à frente e queixo levantado. A coroa ligeiramente torta, olhos semicerrados e sorriso amplo comunicam autoconfiança excessiva. A roupa cobre claramente o corpo: túnica azul-petróleo, calças e botas, com capa azul.

**Escudeiro:** corpo compacto e quase retangular, elmo demasiado grande, ombros tensos e boca preocupada. O escudo é uma tarefa que parece maior do que ele. A proteção deve ser legível mesmo quando o rosto fica parcialmente escondido.

A atuação conjunta funciona quando o rei avança convencido e o escudeiro se antecipa a um perigo que o rei ainda não percebeu.

**Para animar:** o peso do rei aparece na transferência entre os pés, no pequeno atraso da barriga e no seguimento da capa. O escudeiro se apoia atrás do escudo, recebe a força e recupera o equilíbrio. A cabeça conserva forma; o humor não depende de deformá-la.

**Evolução visual:** distinguir a investidura e o equipamento do escudeiro por silhueta e postura. A escala do frame continua definida; acrescentar detalhe indiscriminadamente enfraqueceria a leitura.

### 02 — Nia e bardo: energia versus espetáculo

**Nia:** mulher negra adulta, pequena e decidida, centro de gravidade baixo, membros ágeis e duas armas curtas. A coroa baixa e o cabelo em grandes massas preservam identidade sem transformar cada mecha num detalhe animado.

**Bardo:** chapéu de pena, alaúde, bandeira nas costas e boca de cantor. A teatralidade é o centro de sua personalidade. A composição preserva esses sinais do conceito anterior apreciado pelo autor.

A diferença não depende apenas da cor: Nia tem direção de ataque e prontidão; o bardo abre o peito e alonga a pose ao cantar.

**Para animar:** as machadinhas precisam de cabo, cabeça, orientação do fio e empunhadura coerentes. O gesto nasce do ombro e do cotovelo, com apoio dos pés. O bardo mantém uma mão no braço do alaúde e outra na região das cordas; a bandeira acompanha com atraso discreto.

**Limites de papel:** a ação musical é do bardo. A animação de habilidade de Nia deve mostrar uma ordem ou intenção dirigida à companhia, preservando essa autoria.

**Ponto específico de aprovação:** o desenho de Nia foi rejeitado mais de uma vez no histórico. Esta versão continua proposta; só a resposta do autor poderá elevá-la a referência aprovada.

### 03 — Arqueiro e intendente: precisão versus cobrança

**Arqueiro:** corpo estreito, rosto alongado, nariz pontiagudo e expressão excessivamente segura da própria pontaria. O arco cria uma segunda linha reconhecível ao lado do corpo.

**Intendente:** corpo baixo e quadrado, chapéu simples, bigode e expressão cansada. A aljava grande e a palma aberta comunicam serviço pago.

**Para animar:** a puxada termina junto ao rosto; a flecha permanece apoiada antes do disparo, sai no evento de lançamento e deixa de existir sobre a corda depois dele. A mão do arco não troca de lugar sem motivo. No pagamento, a mão que recebe moeda deve ser distinguível da que entrega flechas.

**Regras econômicas visíveis:** falta de moedas interrompe novo fornecimento. As flechas que o imperador já possui continuam disponíveis. A arte não deve introduzir um bloqueio adicional por “estoque físico do vendedor” sem decisão de design.

**Evolução visual:** o intendente evoluído também dispara. Esse conjunto precisa de poses de arma e retorno ao transporte, sem apagar a sua identidade de fornecedor.

### 04 — Imperador de armadura e dançarina: peso versus leveza

**Imperador:** grande massa de placas simples, elmo fechado, cabeça afundada entre ombreiras e postura cansada. A personalidade aparece na inclinação do tronco, nos braços e no peso dos passos.

**Escudeira:** mulher adulta, dança confiante, rosto expressivo e vestuário prático. Braços, pés e tecido criam direção e ritmo; a roupa precisa continuar dentro do envelope de 64×64.

A dupla oferece outra forma de humor: um corpo parece carregar o mundo enquanto o outro parece aliviar esse peso pelo movimento.

**Para animar:** o imperador transfere massa antes de completar a passada; ao sentar, dobra joelhos e quadril de forma legível. A vegetação é efeito ligado à recuperação, separado do corpo. A dançarina precisa de apoios e deslocamento do centro de gravidade, mesmo num ciclo executado no sítio.

**Pendente real:** o armamento e a coreografia ofensiva deste quarto perfil não estão fechados nas fontes consultadas. O conceito apresentado não inventa uma arma para resolver essa lacuna. O bloco completo de combate dele dependerá desse fechamento; sua apresentação visual e os ciclos já definidos podem ser aprovados separadamente.

## 6. Rostos pequenos com personalidades distintas

O guia do projeto orienta olhos pequenos e afastados, narizes marcantes e bocas largas. Em vez de copiar a mesma cara, propõe-se esta distribuição:

| Personagem | Sinal principal de rosto ou postura |
| --- | --- |
| Rei | Pálpebras pesadas, sorriso satisfeito, cabeça recuada |
| Escudeiro | Olhos sob o elmo, boca tensa, queixo recolhido |
| Nia | Olhar focado, sobrancelha ativa e sorriso desafiante |
| Bardo | Olhos fechados ao cantar, boca aberta e peito erguido |
| Arqueiro | Um olho de mira mais fechado, nariz longo e queixo projetado |
| Intendente | Sobrancelha baixa, bigode e expressão de impaciência |
| Imperador de armadura | Rosto oculto; ombreiras, cabeça baixa e mãos comunicam emoção |
| Dançarina | Rosto aberto, nariz e sorriso simples, gesto expansivo |

Para os personagens pequenos, a proposta parte de cabeças com aproximadamente 10–14 pixels úteis por eixo, conforme o modelo. Dentes são blocos selecionados; não se tenta desenhar uma dentição inteira.

Expressões a preparar conforme o papel: normal, foco/ataque, medo, impacto, ferido, vitória e repouso/queda. Camadas de rosto podem ser reutilizadas quando forem visualmente adequadas, conservando alinhamento com a cabeça em cada quadro.

## 7. O que “animações completas” deverá incluir

A entrega só deve usar essa expressão quando cobrir os estados da personagem, os dois sentidos de leitura necessários e as ações do seu papel. Uma folha de caminhada isolada não cobre o pedido.

### Base comum proposta

Os quatro ciclos centrais vêm da Animation Bible. Os demais são propostas de produção e precisam acompanhar as ações existentes no jogo.

| Tag de autoria | Quadros orientadores | Comportamento |
| --- | --- | --- |
| idle | 6 | Respiração e atuação própria, com pés estáveis |
| walk | 8 | Contatos opostos e passagem; deslocamento no mundo vem da simulação |
| attack | 5 | Antecipação, ação e recuperação; corpo ofensivo conforme o papel |
| die | 7 | Queda e pose final legível; não significa morte definitiva automática |
| run | 6 | Corrida com apoios e fôlego visível |
| hit | 2 | Reação curta, mantendo ancoragem |
| turn | 2–3 | Mudança de direção sem salto involuntário do pivot |
| interact | 4 | Gesto de interação |
| celebrate | 6 | Vitória coerente com personalidade |
| rise | 6, proposta | Voltar ao apoio depois de recuperação válida |
| flee | 6 | Acompanhantes nos estados de recuo/fuga aplicáveis |

A regra central documentada é 10 fps para idle/walk/attack/die. A própria Bible apresenta cadências distintas para alguns extras. As durações serão registradas por quadro, sem transformar essa tabela numa alteração dos tempos de combate.

A queda do rei e a coroa precisam respeitar as regras da simulação. A coroa deve poder sair do corpo, permanecer no chão e seguir o evento correto; pintar uma coroa presa em todos os quadros de queda causaria contradição visual.

### Ações específicas por dupla

| Personagem | Conjuntos específicos a produzir após aprovação |
| --- | --- |
| Rei | Ataque de espada, ordem/Vigília, pagar, recolher moeda e reação à perda da coroa |
| Escudeiro | Preparar bloqueio, sustentar, receber impacto, perder proteção, equipar; espada e ataque na evolução |
| Nia | Ataque curto com as duas machadinhas e ordem à companhia; variação de pose não cria uma habilidade nova |
| Bardo | Tocar, encantar, incentivar, sinalizar serviço indisponível e promover na evolução de Maestro |
| Arqueiro | Preparar, puxar, soltar, recuperar/recarregar, marcar, pagar e sinalizar aljava vazia |
| Intendente | Receber pagamento, buscar e entregar flechas, sinalizar falta de pagamento; preparar e disparar na evolução |
| Imperador de armadura | Passo pesado, sentar, recuperar e levantar; combate conforme armamento posteriormente fechado |
| Dançarina | Início da dança, ciclo de apoio, transição e fim; diferenciação da dança evoluída e seu efeito |

Ataques, pagamento e conversão precisam de um momento de ação identificável. Um efeito visual não concede dano, flechas, cura ou conversão por conta própria.

### Movimento secundário

- Rei: capa e massa abdominal acompanham o corpo com atraso pequeno.
- Escudeiro: escudo responde à força, não balança sem peso.
- Nia: capa curta e arma livre seguem trajetórias independentes.
- Bardo: tecido da bandeira e pena acompanham a atuação sem cobrir o rosto.
- Arqueiro: corda, membros do arco e braço de puxada distinguem preparação e disparo.
- Intendente: a carga de flechas acompanha o tronco sem se desmontar em pixels soltos.
- Imperador: ombreiras e placas conservam volume, com os apoios transmitindo peso.
- Dançarina: tecido segue a viragem; pés continuam mostrando qual lado sustenta o corpo.

## 8. Direções, pivots e camadas

A apresentação principal deve funcionar virada à direita e à esquerda. A comparação incluirá mão da arma, perfil do rosto, aljava, escudo e bandeira.

O runtime atual usa espelhamento. Se uma assimetria exigir arte própria para cada lado, exportar duas direções só resolverá a autoria: a seleção da direção também precisará de ligação na apresentação do jogo. Essa diferença deve ficar documentada.

O pivot é o contato central dos pés no frame de referência. Ele permanece fixo nas tags. Na queda, a extensão visual muda; a origem do personagem não deve saltar.

Camadas de autoria propostas:

- body: torso e membros.
- head/face: identidade e expressão.
- weapon/shield: equipamento móvel.
- cloth: capa, bandeira e tecido relevante.
- crown: destacável quando a regra pedir.
- fx: arcos de ataque, notas, sinais e vegetação, exportados separadamente quando apropriado.

Pontos de referência por quadro: mão da arma, origem de projétil, cabeça, mão de transporte e origem de efeito. Os dados precisam dizer se são coordenadas locais do frame ou offsets em relação ao pivot.

## 9. Compatibilidade concreta com o código atual

Foi consultado o manifesto de renewal e a leitura de arte em OriginalArt/ActorAction.

### Estado observado

Nos seis perfis iniciais das duplas, o manifesto atual usa células de **192×192**, com quatro quadros por personagem. As tags são idle 0–0, walk 0–3 e flee 0–3; as durações registradas são 160 ms. A tela de 192×192 inclui transparência: esse número não equivale à altura do corpo visível.

OriginalArt já lê tamanho de frame, foot, regiões, duração e tags. Isso dá uma base para células de dimensões diferentes. Porém, a entrada de renewal tem prioridade: os novos perfis precisam ser ligados ao lugar efetivamente lido pelo runtime.

ActorAction conhece idle, walk, work, attack, hit, flee e die. As ações específicas como tocar, entregar flechas ou marcar não estão todas mapeadas nessa seleção genérica.

### Consequência para o futuro ZIP

O pacote deve trazer arte e metadados compatíveis, com indicação clara do que está pronto para importação e do que requer ligação de evento. A presença de uma tag nova num JSON não comprova que a simulação já a dispara.

O trabalho de integração posterior precisará:

1. Ligar os novos tamanhos e pivots ao manifesto realmente selecionado.
2. Confirmar que cada ação visual corresponde ao estado/evento certo.
3. Sincronizar a saída da flecha e o impacto ao evento de combate, preservando a autoridade da simulação.
4. Tratar ações únicas e loops corretamente.
5. Verificar inversão lateral e camadas de equipamento.
6. Comparar os personagens sobre cenários claros e escuros do jogo.
7. Conferir a visualização no enquadramento normal e em dispositivo pequeno.

Os conceitos não alteram essas ligações e não foram apresentados como arte já integrada.

## 10. Organização prevista do ZIP

| Pasta | Conteúdo |
| --- | --- |
| 01-frames | PNGs transparentes individuais, agrupados por personagem, forma, direção e ação |
| 02-spritesheets | Folhas por personagem e ação, sem texto dentro das células |
| 03-metadata | Tamanho, pivot, regiões, tags, durações, loops, pontos e eventos visuais |
| 04-previews | GIFs de cada ação e reprodução conjunta para revisão |
| 05-godot | Manifesto e instruções de importação para o caminho real do projeto; prévia quando aplicável |
| 06-fontes | Fontes de autoria e camadas efetivamente produzidas, identificadas pelo formato real |
| LEIA-ME.md | Relação das ações entregues, dimensões, uso e pendências concretas |

Amostras de nome: nia_base_right_attack_003.png; squire_base_left_block_002.png; quiver_squire_evolved_right_shoot_003.png.

As formas evoluídas devem ser identificadas separadamente. A completude será conferida contra uma lista de ações por personagem, evitando uma contagem de arquivos que esconda estados ausentes.

## 11. Critérios para aceitar os sprites de produção

### Integridade

- As imagens pequenas medem efetivamente 64×64; grandes correspondem ao tamanho aprovado.
- Alpha fora do corpo e transparência correta nas folhas.
- Nenhuma arma, pena ou fita cortada na borda.
- Regiões válidas e nomes únicos.
- Durações positivas, tags válidas e ciclos com início/fim corretos.
- Arquivo-fonte abre no formato declarado.

### Desenho

- Cabeça e membros conservam massa de um quadro para outro.
- Rosto continua reconhecível nas poses extremas.
- Contorno, paleta e densidade pertencem à mesma família.
- Armas têm empunhadura, orientação e alcance visual compreensíveis.
- A leitura de silhueta distingue os oito personagens.
- Nenhum acompanhante foi aumentado por escala de renderização para compensar falta de desenho.
- O porte do personagem continua coerente com portas, tropas e cenário.

### Movimento e jogo

- Pés de apoio não flutuam ou deslizam involuntariamente.
- Caminhada e corrida têm poses de contato e passagem reais.
- Cada ataque possui antecipação e recuperação adequadas à arma.
- O projétil desaparece do arco ao ser lançado.
- Pagamento e entrega têm mãos e objeto em posições coerentes.
- O bardo executa a ação musical; Nia ordena.
- A dançarina mantém equilíbrio e continuidade do tecido.
- O último quadro da queda permanece legível no chão.
- Os ciclos repetem sem um salto visível entre último e primeiro quadro.
- A animação foi vista em loop e em transições, além da inspeção estática.

A validação artística é do autor. Medir arquivos e verificar tags é necessário, mas não substitui a aprovação de personalidade, rosto e movimento.

## 12. Fontes web consultadas

Todas acessadas nesta sessão em 18/10/2026. Os princípios foram resumidos e adaptados ao jogo; números de frame e papéis vêm das fontes do Empire ou estão identificados como proposta.

| ID | Fonte primária | Assunto consultado |
| --- | --- | --- |
| S01 | [Saint11 — Cluster Sketching and Painting](https://saint11.art/pixel_art_articles/article2/) | Grupos de pixels, massas e ruído |
| S02 | [Saint11 — Anti-Alias and Banding](https://saint11.art/pixel_art_articles/article5/) | Bordas, jaggies, suavização e banding |
| S03 | [Saint11 — Basic Color Theory](https://saint11.art/pixel_art_articles/article6/) | Valor, saturação, temperatura e relações de cor |
| S04 | [SLYNYRD — Pixelblog 8: Intro to Animation](https://www.slynyrd.com/blog/2018/8/19/pixelblog-8-intro-to-animation) | Poses principais, caminhada/corrida e duração |
| S05 | [SLYNYRD — Pixelblog 9: Melee Attacks](https://www.slynyrd.com/blog/2018/9/8/pixelblog-9-melee-attacks) | Ataque lateral, arma, postura e resposta |
| S06 | [SLYNYRD — Pixelblog 55: Top Down Character Animation](https://www.slynyrd.com/blog/2025/3/24/pixelblog-55-top-down-character-animation) | Consistência de volume, vistas e simplificação para movimento |
| S07 | [SLYNYRD — Pixelblog 56: Top Down Character Attack Animation](https://www.slynyrd.com/blog/2025/5/23/pixelblog-56-top-down-character-attack-animation) | Mão da arma, direção, fases e tempo dos ataques |
| S08 | [SLYNYRD — Pixelblog 57: Knights, Monsters, & Castles](https://www.slynyrd.com/blog/2025/7/28/pixelblog-57-knights-monsters-amp-castles) | Anatomia, armadura e materiais |
| S09 | [Aseprite — Animation](https://www.aseprite.org/docs/animation/) | Quadros, camadas, cels e duração |
| S10 | [Aseprite — Tags](https://www.aseprite.org/docs/tags/) | Organização de ciclos e direção de reprodução |
| S11 | [Aseprite — Slices](https://www.aseprite.org/docs/slices/) | Regiões, pivots e exportação de dados |
| S12 | [Aseprite — Sprite sheets](https://www.aseprite.org/docs/sprite-sheet/) | Folhas, importação e exportação |
| S13 | [Aseprite — Onion Skinning](https://www.aseprite.org/docs/onion-skinning/) | Comparação de quadros |
| S14 | [Godot — CanvasItem: TextureFilter](https://docs.godotengine.org/en/stable/classes/class_canvasitem.html#enum-canvasitem-texturefilter) | Nearest e linear |
| S15 | [Godot — SpriteFrames](https://docs.godotengine.org/en/stable/classes/class_spriteframes.html) | Quadros, duração e loops em recurso de prévia |

Os tutoriais foram usados como referências de método. As imagens dos personagens foram geradas para esta proposta usando criação de imagem integrada, com referências do próprio Empire. Não foram baixados sprites de terceiros para compor os conceitos.

## 13. Aprovação necessária para a próxima etapa

A revisão pode ser feita por dupla: **01 Rei; 02 Nia; 03 Arqueiro; 04 Imperador de armadura**.

Para cada uma, a aprovação deve fechar a identidade do corpo, o rosto, o equipamento, a relação de porte com o acompanhante e a paleta dominante. Uma dupla aprovada pode seguir para autoria nativa enquanto outra recebe revisão.

A comparação do elenco é referência de intenção de escala. O primeiro passe nativo deverá confirmar essas relações com os números da tabela e com as poses extremas, antes de multiplicar quadros.

O quarto imperador permanece separado do trio inicial. Sua aprovação visual pode ocorrer agora; a animação ofensiva completa exige fechar seu armamento.

## Anexo — instruções de geração das pranchas

Os prompts completos usados na criação integrada seguem abaixo. São especificações de intenção; o cumprimento das medidas nativas será aferido na produção de sprites, não inferido do texto do prompt.


### Prancha 01 — Rei e escudeiro

```text
Use case: stylized-concept
Asset type: Pixel-art CHARACTER DESIGN APPROVAL BOARD for Empire, an existing side-scrolling 2D medieval game; this is a pixel-native sprite concept study, NOT a high-resolution cartoon illustration.
Input images: Image 1, older king and squire: identity reference ONLY (fat king, crown, blue/teal clothes, protective smaller squire). Redesign their silhouette and acting. Image 2, original soldier: reference for simple black-edged pixel clusters, modest detail and absurd facial charm, NOT a character to copy.
Create one beautiful, restrained landscape design board, ideally 1536x1024. Warm off-white flat background, sparse graphite typography. Title exact "01 · REI E ESCUDEIRO", subtitle "ESTUDO DE PERSONAGENS". Labels "REI · 96×96" and "ESCUDEIRO · 64×64". Small bottom caption "CONCEITO PARA APROVAÇÃO". No decorative frames, scenery or gradients.
CRITICAL PIXEL PRODUCTION MEDIUM: Draw low-resolution sprites FIRST on one consistent underlying pixel grid, then enlarge nearest-neighbor. Every visible source pixel in the large character presentations must be an equal crisp square about 6×6 output pixels, including face, outlines, boots, sword. Absolutely NO fine resolution illustration lines, no tiny high-res texture pixels, no antialiasing, no mixed pixel scales. A low-res pixel drawing, NOT a detailed illustration with pixel filter.
Main upper 65%: Show two full-body playable side-view/very slight front three-quarter sprites facing right, feet EXACTLY on the same thin ground guide. King roughly 70 source pixels tall, 65 wide including sword, fitted in a 96 canvas. Squire roughly 39 pixels tall, 32 wide including shield, fitted in 64 canvas. Clear actual size difference, same pixel size, king near 1.8× body height. Keep main art entirely separated, no overlap.
KING: An extraordinarily fat, pear-shaped, self-important middle-aged king, VERY caricatured and unlike generic fantasy royalty. Tiny crooked gold crown, ruddy hair tufts, huge projecting potato nose, widely separated small pupils and half-closed eyelids, enormous horizontal smile with only 3 clear square tooth blocks. Broad cheek and fleshy chin, short arms and comically short legs; his stomach protrudes far beyond his chest. Full long-sleeved petroleum-teal tunic over trousers, cream collar/cuffs, gold belt buckle, practical broad brown boots. Short royal cobalt cape with simplified cream edge, stopping above boots so leg silhouettes stay visible. One stout short steel sword with an obvious grip and guard, downward safe relaxed pose, sword unambiguously separate from body. Self-satisfied expression, lifted chin, chest back, belly forward. Keep it charming, strange and funny, not baby-like or cute chibi. 1 logical pixel black outline, just TWO flat values per material, broad deliberate clusters.
SQUIRE: A small adult with compact rectangular body, hunched shoulders and knees together; huge oversized squat iron helmet with a low brim covering the top of the small eyes. Huge awkward clenched-tooth mouth and bulbous SHORT nose, an anxious dutiful expression opposite to the king's confidence. Cream sleeves, teal tabard, dark trousers, brown boots. A wooden shield taller than his torso, simple steel boss and one blue stripe, held forward firmly. The shield must leave his expressive lower face visible. He looks like he takes this job far too seriously. No crown and no sword in his base main pose.
Bottom 25%: four SMALLER pixel action KEY POSE studies, at a common smaller integer magnification, spaced with generous margins: king preparing a sword slash, king follow-through with belly and cape lag, squire leaning behind raised shield, squire recoiling from shield impact. These are readable distinct poses, NOT cloned or merely translated sprites. Caption exact "INTENÇÃO DE MOVIMENTO". Same identity, equipment and proportions in all studies. We are planning animation, not claiming this is a finished animated sprite sheet.
The faces must work with 12-18 source pixels, no hundreds of tiny details. Humor comes from contrasting proportions, nose/mouth/eyelids and acting. No beard, no exposed belly or bare flesh tunic, no floating limbs, no weapon fusion, no glowing background.
```

### Prancha 02 — Nia e bardo

```text
Use case: stylized-concept
Asset type: Low-resolution pixel-native sprite design approval board for Empire, a medieval side-scrolling 2D game.
Input images: Image 1 (king approval board) is a reference for board layout and pixel medium, not for body shape. Image 2 (older Nia/bard illustration) is ONLY a reference for the existing bard's feathered hat, lute and back-mounted banner, and Nia being a Black adult empress. Nia's previous visual design was REJECTED: create a genuinely different, compact, opinionated sprite design. Image 3 original soldier is a reference for facial simplicity.
Draw directly as small pixel sprites enlarged nearest-neighbor, NOT a high resolution illustration made to look pixelated. Crisp equal square logical pixels, black ONE logical pixel outlines, TWO flat tones per material, broad deliberate color clusters. Logical pixels about 7 output pixels in main art; no thin drawing below the grid. Zero gradients or realistic shading, no airbrush, no texture, no antialias.
Landscape 1536x1024, clean warm-ivory board, restrained pixel typography. Exact heading "02 · NIA E BARDO", subheading "ESTUDO DE PERSONAGENS"; individual labels "NIA · 64×64" and "BARDO · 64×64"; bottom "CONCEITO PARA APROVAÇÃO". Main top two-thirds shows both whole figures on the SAME horizontal ground line with generous separation. Neither body is tall: Nia 44 native pixels tall with all hatchets inside a 64×64 logical cell, bard 43 body pixels including hat, max 58 pixels including banner, also a genuine 64×64 envelope. The banner must FIT the envelope, not be a tall decorative prop outside it. Same logical pixel size for both.
NIA: unmistakably ADULT Black woman, short and wiry, kinetic forward-leaning angular silhouette, broad practical boots and tiny quick hands. Angular compact natural afro formed from 3-4 big coherent masses, low gold circlet that follows the head, small red jewel. No fine braids, individual curls or ponytail. Determined raised eyebrows, small widely separated pupils, cheeky sideways grin with just two or three square tooth blocks, visibly confident and impatient. Her comical personality comes from cocky acting, compact limbs and spring-loaded stance, with the same respectful caricature language used for the entire cast. Short cream sleeved tunic over simple charcoal vest, warm red half-cape cut above knees, red waist sash, brown short boots and forearm bracers. NO generic fantasy breastplate or ornate armor; she is nimble and impulsive. Two compact functional single-bit STEEL HATCHETS with short straight wood handles: each head has a clear rectangular socket around handle and one simple crescent cutting edge, correct grip and separation from hands. Exactly TWO axes, not giant battle axes, not knives, not a combined object. Relaxed main pose with one hatchet low, one near shoulder, axes not covering face.
BARD: small stout ADULT, theatrical loudmouth with a much longer curved nose, eyes squeezed in passionate singing, huge rectangular open mouth, one visible tooth block. Must be completely different from Nia, king and helmeted squire. Oversized SOFT mustard yellow hat folded sharply sideways with one simple cream feather, burgundy vest, ivory sleeves, green-dark trousers, brown shoes. Round 12-pixel-wide wooden lute held plausibly: fretting hand on neck, strumming hand over strings; strings suggested by 2 short pixel lines only. A SMALL ivory/gold banner on a wooden pole strapped to back, visible but not dominating silhouette. Bard's face, lute and flag separated by negative spaces, mouth uncovered. Overall silhouette a jaunty triangle with hat and lute jutting in opposite directions. Keep visual identity of approved earlier bard, greatly simplify for native pixel animation.
Bottom strip: four small actual ACTION KEY POSE studies, all smaller integer zoom and consistent proportions: Nia low pre-strike, Nia compact fast hatchet slash with ONE clean pixel arc, bard strumming with closed eyes, bard leaning into a full voiced song while banner cloth lags. Exact strip title "INTENÇÃO DE MOVIMENTO". Poses must involve real arm/leg changes, not whole-sprite translation. These are concept poses, not a claimed finished animation.
Distinct personalities and differentiated faces. No giant anime eyes, baby proportions, giant weapons, shiny 3D metal, dense fabric folds, black glow backgrounds, busy accessories, floating items or inconsistent scale.
```

### Prancha 03 — Arqueiro e intendente

```text
Use case: stylized-concept
Asset type: Pixel-native character sprite design approval board for Empire, existing medieval side-view game. Concept and key poses before user approval, not an animation sprite sheet.
Input images: Image 1 king approval board gives the SAME pixel medium and board design. Image 2 older archer/quartermaster illustration gives identities only: tall imperious archer, short grumpy arrow merchant. Redesign more distinctive caricatures rather than copying the drawing. Image 3 original soldier sets simple face readability.
Render small pixel sprites first, then enlarge nearest-neighbor, crisp equal logical squares about 6 output pixels on main figures. ONE logical pixel black contour, TWO flat tones per material, no gradient, no airbrush, no painting, no antialias or high-resolution fine lines. The smallest facial pixel is the same size as a cloak pixel. Strong coherent clusters and clear empty spaces.
Clean landscape 1536x1024 warm off-white board, generous margins. Exact title "03 · ARQUEIRO E INTENDENTE", subtitle "ESTUDO DE PERSONAGENS", labels "ARQUEIRO · 96×96" and "INTENDENTE · 64×64", bottom caption "CONCEITO PARA APROVAÇÃO".
Main upper area shows two FULL BODY figures both facing right in side-view with slightly turned faces so expressions read, feet on EXACT same fine ground guide. Archer narrow 66 native pixels tall including crown, fits a 96 cell with his bow; attendant 37 body pixels tall plus arrow fletching max 53 high and within 64 cell. SAME logical pixel size, obvious height difference. Archer tall and THIN, attendant squat and SQUARE; neither is a resized duplicate.
ARCHER EMPEROR: tall ridiculously lanky and finicky ADULT, long triangular face with narrow projecting pointed nose, very long chin, one half closed eye and one squinting eye, small separated pupils, smug sly little grin showing two square teeth. Bony elbows, narrow shoulders, slight dignified hunch, long skinny legs and narrow boots. Olive hood with 3-point small gold crown emerging around forehead, teal short asymmetric shoulder cape stopping at hips, cream sleeves and olive tunic, brown belt. Minimal ornament, one gold clasp. A plausible tall recurved wooden bow with curved limbs, two clearly attached string ends, clean taut straight string, grip at center held in one hand. String NOT passing through face. Back quiver only a few visible arrow fletchings. Bow taller than torso but shorter than entire character; leave margins inside the 96 canvas. His expression suggests he is taking an unreasonably careful aim at an easy target.
QUARTERMASTER / ARROW SQUIRE: tiny stocky middle-aged ADULT, broad short face, square bulbous nose unlike archer's pointed nose, low scowling brows, small dark moustache and visibly unimpressed closed mouth. Red-orange soft medieval cap, muted green vest, ivory sleeves, dark pants and heavy little boots. Oversized but compact wooden/leather arrow pack strapped high on back, 5 coherent ivory fletching shapes, not dozens of tiny arrows. One hand holds a bundle of exactly 3 arrows, the other opens a palm asking for payment. A clear pouch on belt. Comical tired merchant attitude, different from king's anxious helmeted squire and bard's joyful singer.
Bottom strip with exact label "INTENÇÃO DE MOVIMENTO": 4 distinct miniature key poses at common integer zoom, matching identities and proportions: archer drawing bow with arrow nocked and draw hand at jaw, archer following through just after release (no arrow still on string), quartermaster reaching into quiver, quartermaster offering arrow bundle while receiving one coin. Keep anatomy functional and the bow's limb-string triangle physically comprehensible in draw pose. No extra limbs or two bows. Not mere translated clones.
No painterly detail, no anime eyes, no giant head covering a tiny child body, no ornate fantasy filigree, no glow, no scenery. Visible personality from silhouette, hands and faces, readable in low resolution.
```

### Prancha 04 — Imperador e dançarina

```text
Use case: stylized-concept
Asset type: Pixel-native CHARACTER APPROVAL BOARD for a previously planned FUTURE unlockable emperor and his dancing squire in Empire, a side-scrolling medieval 2D game.
Input images: Image 1 existing king concept board is a reference for pixel language, layout and humorous chunky shape clarity. Image 2 original soldier supports simple facial grammar. Create DIFFERENT characters, not reskins.
Medium: strict small-native-pixel sprite designs, nearest-neighbor enlarged. Logical pixel equally about 6 output pixels in both main characters, one logical pixel black outline, TWO flat values per material, sparse clear clusters, NO fine texture, antialias, smooth illustration or realistic painting.
1536x1024 landscape board on warm ivory, generous spacing and minimal exact typography: title "04 · IMPERADOR E DANÇARINA"; subtitle "DESBLOQUEÁVEL FUTURO · CONCEITO"; labels "IMPERADOR · 128×128" and "ESCUDEIRA · 64×64"; bottom "CONCEITO PARA APROVAÇÃO". Do not give the emperor a new lore name.
Two full bodies on the SAME thin floor baseline, same logical pixel scale: emperor about 92 native pixels high, squarish 65 wide, within 128 cell; adult dancing squire body about 43 high and all gesture/ribbons within 64 cell. Obvious roughly double body height, shared visual universe, not a separate style.
FUTURE EMPEROR: an enormous, obscure but sympathetic fully armored ADULT with tragic weary personality, humor entirely in body language because HELMET COMPLETELY COVERS FACE. Silhouette a huge rounded RECTANGLE like a tired cupboard: gigantic simple pauldrons sagging, small sunk helmet with downward slotted visor, wide gorget, big gauntlets hanging at sides and slightly turned-in chunky feet. Use broad matte charcoal and faded blue-steel plates, a little desaturated plum cloth, minimal dull gold crown-like ridge integrated on helmet. NOT red glowing evil eyes, NOT demonic, NOT intricate gothic armor, NO skull ornaments. He seems overburdened and gentle, shoulders slumped, knees a little bent. Keep armor 5-6 strong plates with plain flat surfaces, each readable at native pixels. Closed helmet doesn't show eyes, nose or mouth. NO invented weapon, shield or giant hammer: main hands empty and resting heavily. The design must feel comical, melancholic and a little mysterious within the same cast as the fat king.
DANCING SQUIRE: short ADULT woman with buoyant asymmetrical dance pose, one raised hand and opposite foot pointed out, completely opposite to emperor's heaviness. Copper-red hair as one big side bun and short fringe; very long playful nose, small eyes nearly closed in joyful concentration, big expressive grin with two clear square teeth. Simple cream blouse, muted sage green short overskirt over practical dark leggings, copper-orange belt sash with two short broad cloth tails that remain in canvas. Flat comfortable medieval shoes. No sexualization, no jewelry clutter, no magical staff or fantasy weapon. A charming confident dance performer, not a princess, not a child. Movement carried by hands, feet and sash silhouette.
Bottom row with exact caption "INTENÇÃO DE MOVIMENTO": four miniature key poses at common smaller integer zoom: heavy emperor taking a ponderous step, emperor seated with hands on knees in a clear recovery pose and two tiny sprouts growing NEAR boots (plants are separate ground effects), dancer balanced side step with one arm lifted, dancer turn with hands opening and cloth tails following. Distinct anatomical poses not translated copies. Same armor and proportions in every pose. Depict grounded subtle recovery, not a beam or magical particles.
Board is only concept and pose planning, not final complete sprites. Keep exaggerated difference in mass and posture. Exclude elaborate scenery, gradients, fine metal scratches, glow, tiny noisy leaves, realistic proportions and overly cute chibi looks.
```

### Comparação do elenco

```text
Use case: stylized-concept
Asset type: Native-resolution-minded PIXEL SPRITE CAST LINEUP for Empire. This is a comparative scale concept, NOT a high resolution illustration.
Input images 1-4 are design references ONLY for the four previously drawn pairs. Preserve their identities, costumes, color groups and core props, but redraw ALL EIGHT at much LOWER, ACTUAL SPRITE-LIKE RESOLUTION. No enlarging the original illustration; reinterpret it into economical native pixel clusters. User specifically needs genuine 64×64 sprite thinking, not a cosmetic pixel style.
Landscape board approximately 2048×896. Flat ivory, no paper texture, no shadows or gradients. Heading exact "EMPIRE · ESCALA DO ELENCO", subheading "PROPOSTA DE SPRITES · MESMO TAMANHO DE PIXEL". One row of eight FULL BODY pixel sprites, all feet on exactly ONE common horizontal ground guide, arranged in these 4 unmistakable pairs left to right:
1 fat king and small helmeted shield squire;
2 petite Black adult empress Nia with two short hatchets, and feather-hatted lute bard carrying a compact back banner;
3 tall very skinny hooded emperor archer with bow, and short mustached grumpy arrow quartermaster;
4 huge slumped fully closed-armored emperor and cheerful adult dancing woman squire.
CRUCIAL SCALE: Use EXACT same logical pixel unit on ALL EIGHT. Each logical pixel should appear as a visible solid 4×4 output square. King useful height 72 logical pixels; shield squire 38. Nia useful body height 44 with axes remaining in 64 envelope; bard body height 43 and max 55 including compact banner. Archer useful height 68 with bow inside a 96 envelope; quartermaster useful body height 37, max 53 including arrow pack. Heavy emperor useful height 94 within 128 envelope; dancer useful height 43 within 64 envelope. King much wider than archer; heavy much taller and wider than both, all attendants distinctly small. Do NOT normalize figures to same display height, do NOT give small ones bigger pixels.
Make these truly low resolution game sprites: head of Nia roughly 12×14 logical pixels, eyes 1×2 pixels, a mouth 5 pixels wide with 2 tooth blocks. No 100-pixel faces, fine vector outlines, tiny curls, hair strands or fabric texture. King face only about 16×18 pixels; squire face about 10×10. Black contour exactly ONE logical pixel. Use TWO flat shades per material, approximately 12-18 colors per individual sprite, visually bold simple masses. Readable black gaps separate limbs and equipment. Body stance lateral, heads slightly turned so noses/mouths read. Enlarge with hard nearest-neighbor edges, no smoothing.
Keep the king's full teal tunic and cobalt cape and enormous pear belly, the small squire's iron helmet and blue-striped shield, Nia's red cape and cream/charcoal clothes, bard's mustard hat and burgundy waistcoat, archer's olive hood and short teal cape, quartermaster's orange cap and packed quiver, heavy emperor's matte grey armor and plum tabard, dancer's sage skirt/leggings and two orange cloth tails. Their personalities must be different even in tiny pixels, avoiding identical toothy smiles on everyone. The heavy helmet shows no face, his sorrow is posture.
Small exact labels below figures in order: "REI", "ESCUDEIRO", "NIA", "BARDO", "ARQUEIRO", "INTENDENTE", "IMPERADOR", "ESCUDEIRA". Under them exact frame-size labels respectively "96×96", "64×64", "64×64", "64×64", "96×96", "64×64", "128×128", "64×64".
Under the main lineup add a short separate strip of the same eight silhouettes in flat dark graphite at a common 2× logical pixel magnification, on one baseline, same height RELATIONSHIPS, no labels except "LEITURA DA SILHUETA". Bottom small caption "CONCEITOS PARA APROVAÇÃO".
No scenery, UI buttons, decorative frames, weapons not already established, additional characters or inter-character overlap. This is a rigorous low resolution pixel cast sheet for comparing anatomical scale and silhouette, not a fancy fantasy poster.
```

