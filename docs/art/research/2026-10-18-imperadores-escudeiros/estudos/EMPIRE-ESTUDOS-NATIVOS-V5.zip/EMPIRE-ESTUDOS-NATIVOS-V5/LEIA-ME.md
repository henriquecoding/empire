# Empire — estudos nativos V5

Esta entrega estrutura a remodelação: resolução real, luz/sombra, materiais, expressões e campo florido.

Comece por EMPIRE-ESTRUTURA-LUZ-SOMBRA-64x64-V5.md. Os quatro painéis mostram o corpo, a iluminação, os recortes faciais e três paletas de flores.

Os desenhos são estudos estáticos de construção. Não substituem o acabamento do rei, escudeiro ou dançarina apreciado por Henrique. Não são animações completas nem arte pronta para integrar no jogo.

## Pastas

- sprites: oito corpos de referência e o imperador sentado.
- expressions: 43 corpos com estados faciais e 42 cabeças recortadas.
- flowers: três pares de camadas de 192×32, três composições e três estágios estáticos de crescimento.
- diagnostics: oito corpos com cores locais antes dos planos de iluminação.
- source: construtor editável, paleta, medidas, resultados e prompt da composição adicional.

Os PNGs individuais são nativos. As pranchas são ampliações para inspeção. As cores em cinzento são diagnósticas.

## Reconstruir

Requer Python 3.9+ e Pillow 10.1+.

```bash
python3 source/build_native_studies.py
```

As coordenadas e a paleta são definidas no código. O JSON da paleta é um registo exportado.

A validação verifica integridade e continuidade deste ensaio. Não verifica beleza, personalidade, fluidez ou aprovação artística. A imagem gerada adicional de composição não faz parte da prova de dimensão.

Não há ficheiros Aseprite ou ciclos completos neste pacote.

